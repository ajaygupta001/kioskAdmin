const express = require("express");
const {
  register,
  login,
  getAllUsers,
  getUser,
  deleteUser,
  resetPassword,
  checkEmailVerification,
  updateUserAndProductImage,
  getUserEmail,
  updateUserProfile,
  confirmPasswordReset,

} = require("../controllers/userController.js");
// const { adminOnly, userOnly } = require("../middlewares/auth.js");
const verifyToken = require("../middlewares/verifyToken.js");
const multer = require("multer");
const router = express.Router();

const upload = multer();

//route - http://localhost:5000/api/v1/user/register
router.post("/register", register);

//route - http://localhost:5000/api/v1/user/login
router.post("/login", login);

//route - http://localhost:5000/api/v1/user/check-email-verification
router.post("/check-email-verification", checkEmailVerification);

//route - http://localhost:5000/api/v1/user/reset-password
router.post("/reset-password", resetPassword);


//route - http://localhost:5000/api/v1/user/confirmReset-password
router.post("/confirmReset-password",verifyToken, confirmPasswordReset);

//route - http://localhost:5000/api/v1/user/all
router.get("/all", verifyToken, getAllUsers);

// route - http://localhost:5000/api/v1/user/getEmail
router.get("/getEmail", verifyToken, getUserEmail);

// Route - Update user profile
// POST http://localhost:5000/api/v1/user/updateProfile
router.post("/updateProfile", verifyToken, upload.single("profileImage"), updateUserProfile);


// route - http://localhost:5000/api/v1/user/update-user-product
router.post("/update-user-product", verifyToken, updateUserAndProductImage);

// route - http://localhost:5000/api/v1/user/:id  --dynamic ID
router.route("/:id").get(verifyToken, getUser).delete(verifyToken, deleteUser);

// Get active avatar route
//router.post("/avatar/activate", activateAvatar);

// Route to get the active avatar
//router.get("/avatars/active/:userId", getActiveAvatar);

// Example protected route (user)
// router.get("/user-protected", verifyUser, (req, res) => {
//   res.json({ message: "This is a protected route for users" });
// });

// Example protected route (admin)
// router.get("/admin-protected", verifyAdmin, (req, res) => {
//   res.json({ message: "This is a protected route for admins" });
// });

module.exports = router;
