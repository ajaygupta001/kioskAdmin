const express = require("express");
const { createWorkspaceQA, updateProductDetails, updateWorkspaceQA ,getWorkspaceQA, deleteWorkspaceQA} = require("../controllers/workspaceQAController");
const verifyToken = require("../middlewares/verifyToken.js");

const router = express.Router();

// Route to create a new workspace with QA
router.post("/workspaceQA", verifyToken, createWorkspaceQA);

// Route to update product details in a workspace
router.put("/workspace/product", updateProductDetails);

// Route to update questions and answers in a workspace
router.put("/workspace/qa", updateWorkspaceQA);

//route - http://localhost:5000/api/v1/getWorkspaceChat  
router.get("/getWorkspaceChat", verifyToken, getWorkspaceQA);

//route - http://localhost:5000/api/v1/workspaceQA/:workspaceQAId
router.delete("/deleteWorkspaceQA/:workspaceQAId", verifyToken, deleteWorkspaceQA);


module.exports = router;
