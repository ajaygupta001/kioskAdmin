const express = require("express");
const router = express.Router();
//const validApiKey = require('../middlewares/validateApikey.js');
const upload = require("../middlewares/multer.js");
// const { adminOnly, userOnly } = require("../middlewares/auth.js");
const verifyToken = require("../middlewares/verifyToken.js");

const {
  createWorkspaceAndUploadPDF,
  uploadEmbeddingLink,
  getAllWorkspaces,
  getWorkspaceNameById,
  parserPdfUpload,
  deleteWorkspace,
  updateWorkspaceAndDocument,
  getActiveWorkspaces,
  setActiveWorkspace,
  workspaceCreated,
  getActiveWorkspaceLogo,
  workspaceQA,
  // getWorkspaceQA
} = require("../controllers/workspaceController.js");
const app = express();

//Apply the middleware to all routes
//app.use(validApiKey);

//route - http://localhost:5000/api/v1/workspace/create-workspace
router.post(
  "/create-workspace",
  verifyToken,
  upload.fields([{ name: "pdfFile" }, { name: "productImage" }]),
  createWorkspaceAndUploadPDF
);

//router- http://localhost:5000/api/v1/workspace/set-active
router.post("/set-active", verifyToken, setActiveWorkspace);

//router- http://localhost:5000/api/v1/workspace/workspaceStatus
router.get("/workspaceStatus", verifyToken, workspaceCreated);

//router- http://localhost:5000/api/v1/workspace/get
// example:  http://localhost:5000/api/v1/workspace/get?page=1&limit=5
router.get("/get", verifyToken, getAllWorkspaces);

//router-  http://localhost:5000/api/v1/workspace/my-workspace-slug  --dynamic workspaceSlug
router.route("/:slug").delete(verifyToken, deleteWorkspace);

//route - http://localhost:5000/api/v1/workspace/:workspaceSlug  --dynamic workspaceSlug
router.patch(
  "/:slug",
  upload.fields([{ name: "productImage", maxCount: 1 }]),
  updateWorkspaceAndDocument
);

//router- http://localhost:5000/api/v1/workspace/getWorkspaceNameById/:workspace_id
router.get(
  "/getWorkspaceNameById/:workspace_id",
  verifyToken,
  getWorkspaceNameById
);

// Route - http://localhost:5000/api/v1/workspace/getActiveWorkspaceLogo
router.get(
  "/getActiveWorkspaceLogo",
  verifyToken, // Middleware to verify user token
  getActiveWorkspaceLogo // Controller function
);

//router- http://localhost:5000/api/v1/workspace/active
router.get("/active", verifyToken, getActiveWorkspaces);

//route - http://localhost:5000/api/v1/workspace/upload
router.post("/upload", parserPdfUpload);

//route - http://localhost:5000/api/v1/workspace/upload-link
router.post("/upload-link", uploadEmbeddingLink);

//route - http://localhost:5000/api/v1/workspace:slug/update-qa    
router.post("/:slug/update-qa", workspaceQA);

//route - http://localhost:5000/api/v1/workspace/getWorkspaceQA   
// router.get("/getWorkspaceQA",verifyToken, getWorkspaceQA);

module.exports = router;
