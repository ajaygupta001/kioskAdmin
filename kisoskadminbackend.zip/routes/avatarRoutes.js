const express = require("express");
const avatarController = require("../controllers/avataarController.js");
const multer = require("multer");
const upload = multer({ dest: "avatar/" });
// const { adminOnly, userOnly } = require("../middlewares/auth.js");
const verifyToken = require("../middlewares/verifyToken.js");

const router = express.Router();

//route - http://localhost:5000/api/v1/upload-avatar
router.post(
  "/upload-avatar",
  upload.single("avatarFile"),
  avatarController.uploadAvatar
);

//route - http://localhost:5000/api/v1/update-avatar
router.post("/update-avatar", verifyToken, avatarController.updateActiveAvatar);

//route - http://localhost:5000/api/v1/avatar
router.get("/avatar", verifyToken,avatarController.getActiveAvatar);

//route - http://localhost:5000/api/v1/download-avatar/:blobName
router.get("/download-avatar/:blobName", avatarController.downloadAvatar);

//route - http://localhost:5000/api/v1/download-avatarUrl/:blobName
router.get("/download-avatarUrl/:blobName", avatarController.downloadAvatarUrl);

//route - http://localhost:5000/api/v1/downloadZip
router.get("/downloadZip", avatarController.DownloadZip);

module.exports = router;
