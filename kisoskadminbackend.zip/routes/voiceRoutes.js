// routes/voiceRoutes.js

const express = require("express");
const router = express.Router();
const {
  getVoices,
  getFileController,
} = require("../controllers/voiceController");
const { getFileMiddleware } = require("../middlewares/azureBlobService");

// http://localhost:5000/api/v1/get-voices
router.get("/get-voices", getVoices);

//http://localhost:5000/api/v1/files/:url
router.get("/files/", getFileMiddleware, getFileController);

module.exports = router;



