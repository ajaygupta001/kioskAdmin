const mongoose = require("mongoose");

const connectDB = async (uri) => {
  try {
    const connection = await mongoose.connect(uri, {
      dbName: "KioskAdmin",
    });
    console.log(`DB connected to ${connection.connection.host}`);
  } catch (error) {
    console.error("DB connection error:", error);
    process.exit(1);
  }
};

module.exports = connectDB;
