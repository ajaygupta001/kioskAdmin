// azure-cognitiveservices-speech.js
const sdk = require('microsoft-cognitiveservices-speech-sdk');
const path = require('path')
const fs = require('fs')

let SSML = `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xmlns:mstts="http://www.w3.org/2001/mstts" xml:lang="en-GB">
<voice name="__VOICE__">
  __TEXT__
</voice>
</speak>`;

const key = process.env.AZURE_KEY;
const region = process.env.AZURE_REGION;

/**
 * Node.js server code to convert text to speech
 * @returns stream
 * @param {*} key your resource key
 * @param {*} region your resource region
 * @param {*} text text to convert to audio/speech
 * @param {*} filename optional - best for long text - temp file for converted speech/audio
 */
const textToSpeech = async (text, voice, hindi=false) => {

    // convert callback function to promise
    return new Promise((resolve, reject) => {

        let ssml = SSML.replace("__TEXT__", text);
        if (voice == "$GIRL$") {
            if(hindi === 'true'){
                ssml = ssml.replace("__VOICE__", "hi-IN-SwaraNeural");
                ssml = ssml.replace("en-GB", "hi-IN")
            } else{
                ssml = ssml.replace("__VOICE__", "en-GB-BellaNeural");
            }
        }
        else if (voice == "$BOY$") {
            if(hindi === 'true'){
                ssml = ssml.replace("__VOICE__", "hi-IN-MadhurNeural");
                ssml = ssml.replace("en-GB", "hi-IN")
            } else{
                ssml = ssml.replace("__VOICE__", "en-GB-ElliotNeural");
            }
        }
        else {
            ssml = ssml.replace("__VOICE__", "en-GB-BellaNeural");
        }
        const speechConfig = sdk.SpeechConfig.fromSubscription(key, region);
        speechConfig.speechSynthesisOutputFormat = 5; // mp3

        let audioConfig = null;
        // console.log(path.dirname(__dirname));
        const dir = process.env.NODE_ENV === 'production' ? __dirname : path.dirname(__dirname);
        if (!fs.existsSync(`${dir}/public/speech`)) {
            // Directory does not exist, so create it
            if (!fs.existsSync(`${dir}/public`)) fs.mkdirSync(`${dir}/public/`);
            fs.mkdirSync(`${dir}/public/speech`);
        }
        // if (filename) {
        let randomString = Math.random().toString(36).slice(2, 7);
        let filename = `./public/speech/speech-${randomString}.mp3`;
        audioConfig = sdk.AudioConfig.fromAudioFileOutput(filename);
        // }

        const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

        // Subscribes to viseme received event
        synthesizer.speakSsmlAsync(
            ssml,
            result => {

                synthesizer.close();
                resolve({ filename: `/speech/speech-${randomString}.mp3` });

            },
            error => {
                synthesizer.close();
                reject(error);
            });
    });
};

module.exports = textToSpeech;