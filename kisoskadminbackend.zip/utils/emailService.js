const nodemailer = require("nodemailer");

// Create a reusable transporter object using SMTP transport
const transporter = nodemailer.createTransport({
    service: "gmail", // Use 'gmail', 'outlook', or SMTP details for other services
    auth: {
        user: process.env.EMAIL_USER, // Your email
        pass: process.env.EMAIL_PASS, // Your email password or app password
    },
});

// Function to send email
const sendEmail = async (to, subject, text, html) => {
    try {
        let mailOptions = {
            from: process.env.EMAIL_USER,
            to,
            subject,
            text, // Plain text body
            html, // HTML body
        };

        let info = await transporter.sendMail(mailOptions);
        console.log("Email sent: " + info.response);
        return info;
    } catch (error) {
        console.error("Error sending email:", error);
        throw error;
    }
};

module.exports = { sendEmail };
