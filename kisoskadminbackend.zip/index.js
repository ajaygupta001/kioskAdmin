if (process.env.NODE_ENV === "development") {
  require("dotenv").config({ path: ".env.local", debug: false });
  require("dotenv").config({ path: ".env.development", debug: false });
}

const express = require("express");
const path = require("path");
const cors = require("cors");
const compression = require("compression");
const axios = require("axios");
const textToSpeech = require("./utils/tts");
//const details = require("./data.json");
const connectDB = require("./utils/dbConnection.js");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const { errorHandler, pageNotFound } = require("./middlewares/errorHandler.js");
const User = require("./models/user.js");
const { userOnly } = require("./middlewares/auth.js");
const morgan = require("morgan");

const JWT_SECRET = process.env.JWT_SECRET || "H491K3P-T5YMG65-JAJAY21-G5KY9NW";
const ADMIN_JWT_SECRET =
  process.env.ADMIN_JWT_SECRET || "AJAYK3P-T5YMAJ75-JAR7G21-HYTEN04W";

//importing Routes
const authRouter = require("./routes/userRoutes.js");
const workspaceRoutes = require("./routes/workspaceRoutes.js");
const AvataarRoutes = require("./routes/avatarRoutes.js");
const voiceRoutes = require("./routes/voiceRoutes.js");
const WorkspaceQARoutes = require("./routes/workspaceQARoutes.js");
const emailRoutes = require("./routes/emailRoutes");




const mongoURI = process.env.MONGODB_URI || "";
connectDB(mongoURI);

const app = express();

app.use(cookieParser());
app.use(express.json());

// const { config } = require("dotenv");
// config({
//   path: "./config/config.env",
// });

app.use(
  cors({
    origin: "*",
    credentials: true,
  })
);


app.use(compression({ threshold: 9 }));
app.use(express.static(path.join(__dirname, "public")));
app.use(morgan("dev"));

//using Routes
app.use("/api/v1/user", authRouter);
app.use("/api/v1/workspace", workspaceRoutes);
app.use("/api/v1/", AvataarRoutes);
app.use("/api/v1", voiceRoutes);
app.use("/api/v1", WorkspaceQARoutes);

// Use email routes
app.use("/api/v1/email", emailRoutes);

app.get("/api/sse", async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  const segments = req.query.q.split("."); // Split into sentences
  async function sendData() {
    for (const segment of segments) {
      if (segment) {
        const result = await textToSpeech(segment, req.query.voice); // Replace with your function to generate audio URLs
        // console.log(result);
        const data = `data: ${result.filename}\n\n`;
        // console.log(segment);
        res.write(data);
        res.flushHeaders();
      }
    }
    res.write(`data: done\n\n`);
    res.end(); // End the connection once all data is sent
  }
  sendData(); // Send data for all segments
});

app.post("/add-image", async (req, res) => {
  try {
    const { pdf_id } = req.body;

    // Validate if pdf_id exists
    if (!pdf_id) {
      return res.status(400).json({ error: "pdf_id is required" });
    }

    // Make the POST request to the external API
    const response = await axios.post(
      "https://buddy.pharynxai.in/parser//img/add",
      {
        pdf_id: pdf_id,
      }
    );

    // Send back the response from the external API
    res.status(200).json(response.data);
  } catch (error) {
    console.error("Error while making API request:", error.message);

    // Handle different error scenarios
    if (error.response) {
      // The request was made and the server responded with a status code not in the range of 2xx
      res.status(error.response.status).json({ error: error.response.data });
    } else if (error.request) {
      // The request was made but no response was received
      res
        .status(500)
        .json({ error: "No response received from the external API" });
    } else {
      // Something happened in setting up the request
      res.status(500).json({ error: "Failed to make the request" });
    }
  }
});




app.get("/api/tts", async (req, res) => {
  try {
    const result = await textToSpeech(
      req.query.q,
      req.query.voice,
      req.query.hindi
    );
    res.json(result);
  } catch (e) {
    console.error(e.message, e);
    res.status(500).send({ error: "Internal Server Error" });
  }
});

app.get("/api/get-speech-token", async (req, res, next) => {
  res.setHeader("Content-Type", "application/json");
  const speechKey = process.env.AZURE_KEY;
  const speechRegion = process.env.AZURE_REGION;
  if (!speechKey || !speechRegion) {
    return res
      .status(400)
      .send("You forgot to add your speech key or region to the .env file.");
  } else {
    const headers = {
      headers: {
        "Ocp-Apim-Subscription-Key": speechKey,
      },
    };
    try {
      const tokenResponse = await axios.post(
        `https://${speechRegion}.api.cognitive.microsoft.com/sts/v1.0/issueToken`,
        null,
        headers
      );
      // console.log(`${JSON.stringify(tokenResponse)}`);
      return res
        .status(200)
        .send({ token: tokenResponse.data, region: speechRegion });
    } catch (err) {
      console.error(err);
      return res
        .status(401)
        .send("There was an error authorizing your speech key.");
    }
  }
});

// app.post("/api/login", async (req, res) => {
//   const { email, password } = req.body;

//   const user = await User.findOne({ email });
//   if (!user || !(await bcrypt.compare(password, user.password))) {
//     return res.status(401).json({ message: "Invalid credentials." });
//   }

//   // Generate JWT token
//   const token = jwt.sign(
//     { id: user._id, email: user.email },
//     user.role === "admin" ? ADMIN_JWT_SECRET : JWT_SECRET,
//     { expiresIn: "1d" }
//   );

//   res.status(200).json({
//     token,
//     user: {
//       id: user._id,
//       name: user.name,
//       email: user.email,
//       workspace_id: user.workspace_id,
//       workspace_name: user.workspace_name,
//       role: user.role,
//       loginMode: user.loginMode,
//       activeAvatar: user.activeAvatar,
//     },
//   });
// });

if (process.env.NODE_ENV !== "development") {
  app.use(
    express.static(path.resolve(__dirname, "public"), { extensions: ["js"] })
  );

  app.use("/", function (_, response) {
    response.sendFile(path.join(__dirname, "public", "index.html"));
  });
}

app.all("*", function (_, response) {
  response.sendStatus(404);
});

app.use(errorHandler);

app.listen(process.env.PORT, () => {
  console.log(`listening on ${process.env.PORT}`);
});
