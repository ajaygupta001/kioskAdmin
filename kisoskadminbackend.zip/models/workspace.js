const mongoose = require("mongoose");

// const ProductInfoSchema = new mongoose.Schema({
//   product_name: { type: String, required: true },
//   product_id: { type: String, required: true },
//   product_image: { type: String, required: true },
// });

// const questionAnswerSchema = new mongoose.Schema(
//   {
//     // workspace_name: { type: String, required: true }, 
//     question: { type: String, required: true },
//     answer: { type: String, default: null },
//     date: { type: Date, default: Date.now },
//     time: { type: String, required: true },
   
//   },
//   // {
//   //   timestamps: true,
//   // }
// );

const WorkspaceSchema = new mongoose.Schema(
  {
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    pdf_location: { type: String, required: true },
    workspace_name: { type: String, required: true },
    workspace_slug: { type: String, required: true },
    pdf_title: { type: String, required: true },
    pdf_id: { type: String, required: true },
    workspace_id: { type: String, required: true },
    // chat: [questionAnswerSchema],
    product_name: { type: String, required: false },
    product_info: { type: String, required: false },
    product_image: { type: String, required: false },
    is_pdf_file: { type: Boolean, default: false },
    is_pdf_url: { type: Boolean, default: false },
    status: {
      type: String,
      enum: ["active", "inactive"],
      required: true,
      default: "inactive",
    },
  },
  {
    timestamps: true,
  }
);

const Workspace = mongoose.model("Workspace", WorkspaceSchema);

module.exports = Workspace;
