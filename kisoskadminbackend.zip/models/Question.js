const mongoose = require("mongoose");

// // Schema for questions and answers
// const questionAnswerSchema = new mongoose.Schema(
//   {
//     question: { type: String, required: true },
//     answer: { type: String, default: null },
//     time: { type: String, required: true }, 
//   },
//   { timestamps: true }
// );

// // Main workspace schema
// const workspaceSchema = new mongoose.Schema(
//   {
//     workspaceName: { type: String, required: true },
//     workspaceSlug: { type: String, required: true, unique: true, index: true },
//     createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
//     updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//     questionsAndAnswers: [questionAnswerSchema],
//   },
//   { timestamps: true } 
// );

// const WorkspaceQuestion = mongoose.model("WorkspaceQuestion", workspaceSchema);

// module.exports = WorkspaceQuestion;


// Schema for questions and answers
const ChatSchema = new mongoose.Schema(
  {
    question: { type: String, required: true },
    answer: { type: String, default: null },
    time: { type: String, required: true },
    workspaceId: { type: mongoose.Schema.Types.ObjectId, ref: "Workspace", required: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    date: { type: Date, default: Date.now },
    workspaceName: { type: String, required: true },
    workspaceSlug: { type: String, required: true ,index: true },
  },
  { timestamps: true }
);

const QuestionAnswer = mongoose.model("chats", ChatSchema);
module.exports = QuestionAnswer;