const mongoose = require("mongoose");

const avatarSchema = new mongoose.Schema(
  {
    avatarName: {
      type: String,
      required: true,
      // unique: true,
    },
    voiceKey: {
      type: String,
      required: true,
    },
    // blobName: {
    //   type: String,
    //   required: true,
    // },
    isActive: { type: Boolean, default: false },
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },

  { timestamps: true }
);

// avatarSchema.index({ avatarName: 1, user: 1 }, { unique: true });

const Avatar = mongoose.model("Avatar", avatarSchema);
module.exports = Avatar;

