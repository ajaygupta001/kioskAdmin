// Define the data object
const voiceData = {
  "arjun-PrabhatNeural-en-IN": "d88b60ac-f9e7-4339-bc66-d4b4c731bd62",
  "priya-NeerjaNeural-en-IN": "526e21e8-fe26-4694-8323-2081a98ebea0",
  "mei-YanNeural-en-HK": "67df1fae-81bb-4e2f-b44d-610b972bbd1b",
  "kai-SamNeural-en-HK": "224a2f5d-3db4-4e38-b192-19c9b1500e5a",
  "haris-WayneNeural-en-SG": "9c246d74-df5a-418e-b06a-6e5c42ddb8ae",
  "siti-LunaNeural-en-SG": "4beba336-e0cf-47a6-b3b9-c93a5bc65c17",
  "levi-MitchellNeural-en-NZ": "24d4cd09-6d07-4660-b195-f2387fe6625e",
  "sophie-MollyNeural-en-NZ": "74693195-d565-4ae7-ba47-bd85be90996c",
  "ross-AndrewNeural-en-US": "47cee5fd-7e48-40b7-a71d-e6dec12ec9f5",
  "rachel-AvaNeural-en-US": "2489ca9f-abcc-431f-9102-b08d9bb23d46",
  "emily-SoniaNeural-en-GB": "1764c857-3207-4f91-8e6f-7c2971a52749",
  "oliver-RyanNeural-en-GB": "dc7060ea-f70e-4d43-89ff-7d0ce6cc9647",
  "andres-JamesNeural-en-PH": "de7848ed-62df-4f24-8f96-5e15d585cc62",
  "sofia-RosaNeural-en-PH": "44928f81-5437-4c48-8aad-5e6f6fc882e1",
};

// Controller function to give audio object
const getVoices = (req, res) => {
  res.json(voiceData);
};

// Controller function to handle the GET request
const getFileController = async (req, res) => {
  const { url } = req.query;
  //console.log("urlQuery:", url);
  res.json({ base64File: res.locals.base64File });
};

module.exports = { getVoices, getFileController };
