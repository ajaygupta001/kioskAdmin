const { createGzip } = require("zlib");
const { PassThrough } = require("stream");
const axios = require("axios");
const archiver = require("archiver");
const fs = require("fs");
const path = require("path");
const User = require("../models/user.js");
const Avatar = require("../models/avatar.js");
const {
  uploadAvatarZip,
  containerClient,
  createContainerIfNotExists,
} = require("../middlewares/azureBlobService.js");

// For Avatar Upload
const uploadAvatar = async (req, res) => {
  try {
    const { avatarName } = req.body;
    const file = req.file;

    if (!file || !avatarName) {
      return res.status(400).json({ message: "Missing file or avatar name" });
    }

    const { blobName, url } = await uploadAvatarZip(avatarName, file.path);
    await saveAvatarMetadata(avatarName, blobName);

    // Clean up the temporary file
    fs.unlinkSync(file.path);

    res.status(200).json({ blobName, url });
  } catch (error) {
    console.error("Error uploading avatar:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


const updateActiveAvatar = async (req, res) => {
  try {

    const user_id = req.user.id;
    const { avatarName, voiceKey } = req.body;
    if (!avatarName || !voiceKey) {
      return res.status(400).json({
        message: "Avatar Name and Voice Key are required",
      });
    }

    //console.log("Received data:", { userId, avatarName, voiceKey });
    const user = await User.findOne({ _id: user_id });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    let avatar = await Avatar.findOne({ user_id, avatarName });
    if (!avatar) {
     // console.log("Creating new avatar for user:", userId);
      avatar = new Avatar({
        user_id,
        avatarName,
        voiceKey,
        isActive: true,
      });
    } else {
     // console.log("Updating existing avatar for user:", user_id);
      avatar.voiceKey = voiceKey;
      avatar.isActive = true;
    }

 
    await avatar.save();
    //console.log("Avatar saved/updated:", avatar);

    await Avatar.updateMany(
      { user_id, _id: { $ne: avatar._id } },
      { $set: { isActive: false } }
    );

    user.activeAvatar = avatarName;
    user.activeAvatarVoice = voiceKey;
    await user.save();
    console.log("User active avatar and voice updated:", {
      activeAvatar: user.activeAvatar,
      activeAvatarVoice: user.activeAvatarVoice,
    });

    // Respond with the updated avatar and voice key
    res.status(200).json({
      success:true,
      message: "Avatar updated successfully",
      activeAvatar: user.activeAvatar,
      activeAvatarVoice: user.activeAvatarVoice,
    });
  } catch (error) {
    console.error("Error updating avatar:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};






const downloadAvatarUrl = async (req, res) => {
  try {
    const blobName = req.params.blobName;
    const blockBlobClient = containerClient.getBlockBlobClient(blobName);
    const exists = await blockBlobClient.exists();

    if (!exists) {
      return res.status(404).json({ message: "Blob not found" });
    }

    // Generate the URL (either with SAS token or if publicly accessible)
    const url = blockBlobClient.url;
    res.status(200).json({ url });
  } catch (error) {
    console.error("Error generating avatar URL:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const DownloadZip = async (req, res) => {
  console.log("DownloadZip route hit");
  try {
    const response = await axios.get(
      "https://transcribedblobstorage.blob.core.windows.net/paldev/c0b3cc60-6e81-11ef-8ff4-f9428e27b197-IndianWomen2444.zip",
      {
        responseType: "arraybuffer",
      }
    );
    res.set("Content-Type", "application/zip");
    res.send(response.data);
  } catch (error) {
    console.error("Error fetching ZIP file:", error);
    res.status(500).send("Error fetching ZIP file");
  }
};

//
const downloadAvatar = async (req, res) => {
  try {
    const blobName = req.params.blobName;
    // const localFilePath = path.join(__dirname, "downloads", blobName); // Adjust path as necessary
    // const localFilePath = path.join("C:/Users/YourName/Downloads", blobName);
    // Set your local file path
    const localDir = path.join(__dirname, "downloads");
    console.log("sss", __dirname);

    const localFilePath = path.join(localDir, blobName);

    // Ensure the directory exists
    if (!fs.existsSync(localDir)) {
      fs.mkdirSync(localDir, { recursive: true });
    }
    //

    console.log(`Attempting to download blob: ${blobName}`);

    const blockBlobClient = containerClient.getBlockBlobClient(blobName);
    const exists = await blockBlobClient.exists();

    if (!exists) {
      console.error(`Blob not found: ${blobName}`);
      return res.status(404).json({ message: "Blob not found" });
    }

    console.log(`Blob found, starting download: ${blobName}`);
    const downloadBlockBlobResponse = await blockBlobClient.download(0);

    // Create a writable stream for saving the file locally
    const writableStream = fs.createWriteStream(localFilePath);

    // Pipe the blob's readable stream to the writable stream
    downloadBlockBlobResponse.readableStreamBody.pipe(writableStream);

    writableStream.on("finish", () => {
      console.log(`File successfully saved locally: ${localFilePath}`);
      res.status(200).json({ message: "File successfully saved locally" });
    });

    writableStream.on("error", (err) => {
      console.error("Error saving file locally:", err);
      res.status(500).json({ message: "Internal Server Error" });
    });
  } catch (error) {
    console.error("Error downloading and saving avatar ZIP:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const saveAvatarMetadata = async (avatarName, blobName) => {
  try {
    const avatar = new Avatar({ avatarName, blobName });
    await avatar.save();
  } catch (error) {
    console.error("Error saving avatar metadata:", error);
    throw new Error("Could not save avatar metadata");
  }
};

const getActiveAvatar = async (req, res) => {
  try {
    const user_id = req.user.id;
    //console.log("User ID:", user_id);

    const user = await User.findById(user_id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json({
      success: true,
      message: "Active Avataar fetched successfully.",
      activeAvatar: user.activeAvatar,
      avatarVoice:user.activeAvatarVoice,
    });
  } catch (error) {
    console.error("Error fetching active avatar:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

module.exports = {
  uploadAvatarZip,
  saveAvatarMetadata,
  updateActiveAvatar,
  getActiveAvatar,
  uploadAvatar,
  downloadAvatar,
  downloadAvatarUrl,
  DownloadZip,
};
