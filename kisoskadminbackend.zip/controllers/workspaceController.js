require("dotenv").config();
const multer = require("multer");
const FormData = require("form-data");
const axios = require("axios");
const Workspace = require("../models/workspace.js");
const path = require("path");
const fs = require("fs").promises;
const { uploadFileToBlob } = require("../middlewares/azureBlobService.js");
const User = require("../models/user");

// const BASE_URL = "http://localhost:3010/api/workspace";

const BASE_URL = process.env.BASE_URL;
//const PARSER_URL = process.env.PARSER_URL;

// Multer configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, `${file.originalname}`);
  },
});

// Filter to accept only PDF files
const fileFilter = (req, file, cb) => {
  if (file.mimetype === "application/pdf") {
    cb(null, true); // Accept the file
  } else {
    cb(new Error("Only PDFs are allowed!"), false); // Reject file upload
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
});

// Controller to create the workspace and uploading PDF and processing it
const createWorkspaceAndUploadPDF = async (req, res) => {
  try {
    console.log("Request body", req.body);
    const user_id = req.user.id;
    const { workspaceName, productInfo, productUrl } = req.body;
    const pdfFile = req.files?.pdfFile?.[0];
    const productImage = req.files?.productImage?.[0];

    console.log(" Extracted Data:", {
      user_id,
      workspaceName,
      productInfo,
      productUrl,
      pdfFile: pdfFile ? pdfFile.originalname : null,
      productImage: productImage ? productImage.originalname : null,
    });
    
    if (!workspaceName || (!pdfFile && !productUrl)) {
      return res.status(400).json({
        error: "workspaceName and either PDF file or product URL are required.",
      });
    }

    // Deactivate all other workspaces
    // await Workspace.updateMany({}, { status: "inactive" });

    // Create a new workspace
    console.log("Creating workspace...");
    const createWorkspaceResponse = await axios.post(`${BASE_URL}/new`, {
      name: workspaceName,
    });
    const workspaceData = createWorkspaceResponse.data.workspace;
   

    console.log("Workspace created:", createWorkspaceResponse.data);

    if (!workspaceData) {
      throw new Error("Workspace creation failed, no workspace data returned.");
    }
    let pdfData;
    let documentLocation;
    let isPdfFile = false;
    let isPdfUrl = false;

    if (pdfFile) {
      console.log("Uploading PDF file...");
      const formData = new FormData();
      // Handle PDF file upload
      formData.append("file", pdfFile.buffer, {
        filename: pdfFile.originalname,
        contentType: pdfFile.mimetype,
      });

      formData.append("productInfo", productInfo || "");
      // formData.append("temp", temp || "");

      const uploadPdfResponse = await axios.post(
        `${BASE_URL}/${workspaceData.slug}/upload`,
        formData,
        { headers: formData.getHeaders() }
      );
      console.log("PDF uploaded successfully:", uploadPdfResponse.data);
      pdfData = uploadPdfResponse.data.documents[0];
      if (!pdfData) {
        throw new Error("PDF upload failed, no document data returned.");
      }
      documentLocation = pdfData.location.split("custom-documents/")[1];
      // documentLocation = pdfData.location.split("custom-documents\\")[1];
      isPdfFile = true;
      // documentLocation = pdfData.location;

      // Handle platform-specific path separator
    } else if (productUrl) {
      console.log("Uploading document via URL:", productUrl);
      // const formData = new FormData();
      // formData.append("productInfo", productInfo || "");
      // Handle URL upload
      // const uploadLinkResponse = await axios.post(
      //   `${BASE_URL}/${workspaceData.slug}/upload-link`,
      //   formData,
      //   { headers: formData.getHeaders() },
      //   { link: productUrl }
      // );

      const uploadLinkResponse = await axios.post(
        `${BASE_URL}/${workspaceData.slug}/upload-link`,
        { link: productUrl }
      );
      console.log(" URL uploaded successfully:", uploadLinkResponse.data);

      pdfData = uploadLinkResponse.data.documents[0];
      if (!pdfData || !pdfData.location) {
        throw new Error("Link upload failed or no document location returned.");
      }
     
      documentLocation = pdfData.location.split("custom-documents/")[1];
      isPdfUrl = true;
      // documentLocation = pdfData.location.split("custom-documents")[1].replace(/\\/g, '/');
    }
    if (!documentLocation) {
      throw new Error(
        "Failed to parse document location from upload response."
      );
    }

    // Update embeddings
    console.log("Updating embeddings...");
    const updateEmbeddingsResponse = await axios.post(
      `${BASE_URL}/${workspaceData.slug}/update-embeddings`,
      {
        adds: [`custom-documents/${documentLocation}`],
      }
    );
    console.log(" Embeddings updated:", updateEmbeddingsResponse.data);
    console.log(
      "updateEmbeddingsResponse created:",
      updateEmbeddingsResponse.data
    );

    // Handle Image upload to Azure Blob Storage
    let imageBlobData = null;
    if (productImage) {
      console.log(" Uploading product image...");
      imageBlobData = await uploadFileToBlob(productImage, "images");
      console.log(" Image uploaded:", imageBlobData);
    }

    let workspaceList = await Workspace.find({ user_id });
    let statusToUpdate = workspaceList.length > 0 ? "inactive" : "active";

    console.log(" Determining workspace status:", statusToUpdate);

    // await Workspace.updateMany({}, { status: statusToUpdate });

    // Save Necessary Data to MongoDB
    console.log(" Saving workspace data to MongoDB...");
    const newWorkspace = new Workspace({
      workspace_name: workspaceData.name,
      workspace_slug: workspaceData.slug,
      pdf_title: pdfData.title,
      pdf_location: pdfData.location,
      pdf_id: pdfData.id,
      workspace_id: workspaceData.id,
      product_name: workspaceName,
      product_info: productInfo,
      product_image: imageBlobData ? imageBlobData.url : null,
      product_url: productUrl || null,
      // status: "active",
      status: statusToUpdate,
      is_pdf_file: isPdfFile,
      is_pdf_url: isPdfUrl,
      user_id: user_id,
    });

    await newWorkspace.save();

    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    user.workspace_id = workspaceData.id;
    user.workspace_slug = workspaceData.slug;

    await user.save();

    // Send response back to client
    res.status(200).json({
      workspace: workspaceData,
      pdfUpload: pdfData,
      imageUpload: imageBlobData,
      embeddingUpdate: updateEmbeddingsResponse.data,
      isPdfFile,
      isPdfUrl,
      message: "Workspace and document uploaded successfully.",
      newWorkspace,
    });
  } catch (error) {
    console.error("Detailed Error:", error);
    if (error.response) {
      console.error("Error Response Data:", error.response.data);
      console.error("Error Response Status:", error.response.status);
      console.error("Error Response Headers:", error.response.headers);
    }
    res.status(500).json({ error: "An error occurred during the processing." });
  }
};

const workspaceCreated = async (req, res, next) => {
  try {
    
    const user_id = req.user.id;
    let workspaceList = await Workspace.find({ user_id });
    let statusToUpdate = workspaceList.length > 0 ? true : false;

    return res.status(200).json({
      WorkspaceCreated: statusToUpdate,
    });
  } catch (error) {
    console.error("Detailed Error:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while checking workspace status",
      error: error.message,
    });
  }
};

// const makeApiRequest = async (url, data, method = "POST") => {
//   // Validate the method
//   if (typeof method !== "string") {
//     throw new Error("The method must be a string.");
//   }

//   try {
//     const response = await axios({
//       method, // Use the validated method
//       url,
//       data,
//       headers: { "Content-Type": "multipart/form-data" },
//     });
//     return response.data;
//   } catch (error) {
//     console.error("API Request Error:", error);
//     if (error.response) {
//       console.error("Error Response Data:", error.response.data);
//       console.error("Error Status:", error.response.status);
//     }
//     throw new Error(
//       error.response?.data?.detail ||
//         error.message ||
//         "Error during API request."
//     );
//   }
// };

//Delete file after processing or error

const deleteFile = (filePath) => {
  fs.unlink(filePath, (err) => {
    if (err) {
      console.error("Error deleting file:", err);
    } else {
      console.log("File deleted:", filePath);
    }
  });
};

//Controller for uploading PDF and processing it
const parserPdfUpload = async (req, res, next) => {
  upload.single("pdf")(req, res, async (err) => {
    if (err) {
      return res.status(500).json({ error: "File upload failed." });
    }

    if (req.file) {
      console.log("Uploaded File Details:", req.file);
    } else {
      return res.status(400).json({ error: "No file was uploaded." });
    }

    const filePath = req.file.path;
    const pdfFileName = req.file.originalname;

    const fs = require("fs");
    if (!fs.existsSync(filePath)) {
      return res.status(500).json({ error: "Uploaded file not found." });
    }

    try {
      // Step 1: Upload PDF
      const pdfFormData = new FormData();
      pdfFormData.append("document", fs.createReadStream(filePath));
      pdfFormData.append("format", "brochure");

      console.log("Starting PDF upload...");
      const pdfUploadResponse = await axios.post(
        "https://buddy.pharynxai.in/parser/pdf/add",
        pdfFormData,
        { headers: pdfFormData.getHeaders() }
      );
      console.log("PDF Upload Response:", pdfUploadResponse.data);

      const pdfId = pdfUploadResponse.data?.pdf_id;
      if (!pdfId) {
        console.error(
          "PDF ID is undefined. API response:",
          pdfUploadResponse.data
        );
        return res.status(500).json({
          success: false,
          error: "PDF ID is undefined. Check the upload API response.",
        });
      }
      console.log(`PDF uploaded successfully, PDF ID: ${pdfId}`);

      // Step 2: Hit Image Add API
      try {
        console.log("Starting Image Add API...");
        const imgResponse = await axios.post(
          "https://buddy.pharynxai.in/parser/img/add",
          { pdf_id: pdfId }
        );
        console.log("Image added successfully:", imgResponse.data);
      } catch (imgError) {
        console.error(
          "Image Add API Error:",
          imgError.response?.data || imgError.message
        );
        return res.status(500).json({
          success: false,
          error: `Image Add API failed: ${imgError.message}`,
        });
      }

      // Step 3: Hit Layout Add API
      try {
        console.log("Starting Layout Add API...");
        const layoutResponse = await axios.post(
          "https://buddy.pharynxai.in/parser/layout/add",
          { pdf_id: pdfId, score: 0.5 }
        );
        console.log("Layout added successfully:", layoutResponse.data);
      } catch (layoutError) {
        console.error(
          "Layout Add API Error:",
          layoutError.response?.data || layoutError.message
        );
        return res.status(500).json({
          success: false,
          error: `Layout Add API failed: ${layoutError.message}`,
        });
      }

      // Step 4: Hit Figure Add API
      try {
        console.log("Starting Figure Add API...");
        const figureResponse = await axios.post(
          "https://buddy.pharynxai.in/parser/figure/add",
          { pdf_id: pdfId }
        );
        console.log("Figures added successfully:", figureResponse.data);
      } catch (figureError) {
        console.error(
          "Figure Add API Error:",
          figureError.response?.data || figureError.message
        );
        return res.status(500).json({
          success: false,
          error: `Figure Add API failed: ${figureError.message}`,
        });
      }

      // Step 5: Hit Title Add API
      try {
        console.log("Starting Title Add API...");
        const titleResponse = await axios.post(
          "https://buddy.pharynxai.in/parser/title/add",
          { pdf_id: pdfId, score: 0.5 }
        );
        console.log("Layout added successfully:", titleResponse.data);
      } catch (titleError) {
        console.error(
          "Layout Add API Error:",
          titleError.response?.data || titleError.message
        );
        return res.status(500).json({
          success: false,
          error: `title Add API failed: ${titleError.message}`,
        });
      }

      // Step 6: Hit Embeddings Add API
      try {
        console.log("Starting Embeddings Add API...");
        const embeddingsResponse = await axios.post(
          "https://buddy.pharynxai.in/parser/embeddings/add",
          { pdf_id: pdfId }
        );
        console.log("Embeddings added successfully:", embeddingsResponse.data);
      } catch (embeddingsError) {
        console.error(
          "Embeddings Add API Error:",
          embeddingsError.response?.data || embeddingsError.message
        );
        return res.status(500).json({
          success: false,
          error: `Embeddings Add API failed: ${embeddingsError.message}`,
        });
      }

      // Step 7: Hit Embeddings Query  API
      //   const { pdf_id , query } = req.body;
      //   if (!pdf_id || !query) {
      //   return res.status(400).json({
      //     success: false,
      //     error: "Missing required parameters: pdf_id or query.",
      //   });
      // }
      // try {
      //console.log("Starting Embeddings Query API...");
      //   const embeddingQueryResponse = await axios.post(
      //     "https://buddy.pharynxai.in/parser/embeddings/query",
      //     { pdf_id, query}
      // { pdf_id: pdfId, query }
      //   );
      //   console.log("Embeddings added successfully:", embeddingQueryResponse.data);
      // Return successful response
      //  return res.status(200).json({
      //   success: true,
      //   data: embeddingsResponse.data,
      // });
      // } catch (embeddingsError) {
      //   console.error("Embeddings Query API Error:"", embeddingsError.response?.data || embeddingsError.message);
      //   return res.status(500).json({
      //     success: false,
      //    error: `Embeddings Query API failed: ${embeddingsError.message}`,
      //   });
      // }

      // Final response after all steps are done
      return res.status(200).json({
        success: true,
        message: "PDF processed successfully",
        pdfId,
        imgResponse: imgResponse.data,
        layoutResponse: layoutResponse.data,
        figureResponse: figureResponse.data,
        figureResponse: titleResponse.data,
        embeddingsResponse: embeddingsResponse.data,
        //embeddingQueryResponse:embeddingQueryResponse.data,
      });
    } catch (error) {
      console.error(
        "Error during PDF processing:",
        error.response?.data || error.message
      );
      return res.status(500).json({
        success: false,
        error: `PDF upload failed: ${error.message}`,
      });
    } finally {
      // Cleanup: Delete the uploaded file
      deleteFile(filePath);
    }
  });
};

// Controller to update Embedding
const uploadEmbeddingLink = async (req, res) => {
  try {
    const { workspaceSlug, embeddingLink } = req.body;

    // Validate required fields
    if (!workspaceSlug || !embeddingLink) {
      return res
        .status(400)
        .json({ error: "workspaceSlug and embeddingLink are required." });
    }

    console.log("Request Payload:", { workspaceSlug, embeddingLink });

    // Upload link for embedding
    const uploadLinkResponse = await axios.post(
      `${BASE_URL}/${workspaceSlug}/upload-link`,
      { link: embeddingLink }
    );

    console.log("Upload Link Response:", uploadLinkResponse.data);

    // Extract the upload location from the response
    const uploadLink = uploadLinkResponse.data.documents?.[0];
    if (!uploadLink || !uploadLink.location) {
      throw new Error("Link upload failed or no document location returned.");
    }

    const uploadLocation = uploadLink.location.split("custom-documents\\")[1];
    if (!uploadLocation) {
      throw new Error(
        "Failed to parse upload location from the link upload response."
      );
    }

    console.log("Parsed Upload Location:", uploadLocation);

    // Update embeddings with the upload location
    const updateEmbeddingsResponse = await axios.post(
      `${BASE_URL}/${workspaceSlug}/update-embeddings`,
      {
        adds: [`custom-documents\\${uploadLocation}`],
      }
    );

    console.log("Update Embeddings Response:", updateEmbeddingsResponse.data);

    // Send success response back to the client
    res.status(200).json({
      embeddingUpdate: updateEmbeddingsResponse.data,
      linkUpload: uploadLinkResponse.data,
      message: "Embedding link uploaded and embeddings updated successfully.",
    });
  } catch (error) {
    console.error("Error during processing:", error.message || error);

    if (error.response) {
      console.error("Detailed Error Response:", error.response.data);
      return res.status(500).json({
        error:
          error.response.data.error ||
          "An error occurred during the processing.",
      });
    }

    res.status(500).json({ error: "An internal server error occurred." });
  }
};

// Controller to get the workspace name by workspace_id
const getWorkspaceNameById = async (req, res) => {
  try {
    const { workspace_id } = req.params;

    const user_id = req.user.id;
    // console.log("userrr", user_id);
    const workspace = await Workspace.findOne({ workspace_id: workspace_id });

    if (!workspace) {
      return res.status(404).json({ message: "Workspace not found" });
    }

    const user = await User.findById(user_id);
    // const user = await User.findOne({ workspace_id: workspace_id });

    // if (!user) {
    //   return res
    //     .status(404)
    //     .json({ message: "User not found for this workspace" });
    // }

    res.json({
      success: true,
      message: "Workspace Fetch successfully.",
      workspace,
      activeAvatar: user.activeAvatar,
    });
  } catch (error) {
    console.error("Error fetching workspace name:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Controller to get active workspaces by status
const getActiveWorkspaces = async (req, res) => {
  try {
  
    const user_id = req.user.id;
    const workspace = await Workspace.findOne({ status: "active", user_id });
    if (!workspace) {
      return res.status(200).json({ message: "No active workspace found" });
    }
    const user = await User.findById(user_id);
    if (!user) {
      return res.status(200).json({ message: "User not found" });
    }
    res.json({
      success: true,
      message: "Active workspace fetched successfully.",
      workspace,
      activeAvatar: user.activeAvatar,
    });
  } catch (error) {
    console.error("Error fetching active workspace:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Controller to set the Active workspace
const setActiveWorkspace = async (req, res) => {
  try {
    const user_id = req.user.id;
    // console.log("User ID from token:", user_id);
    const { workspace_id } = req.body;

    if (!workspace_id) {
      return res.status(400).json({ error: "Workspace ID is required." });
    }

    await Workspace.updateMany({ user_id }, { status: "inactive" });

    const updatedWorkspace = await Workspace.findOneAndUpdate(
      { user_id, workspace_id },
      { status: "active" },
      { new: true }
    );

    // if (!updatedWorkspace) {
    //   return res.status(404).json({ error: "Workspace not found." });
    // }

    res.status(200).json({
      success: true,
      message: "Workspace activated successfully.",
      workspace: updatedWorkspace,
    });
  } catch (error) {
    console.error("Error setting active workspace:", error);
    res
      .status(500)
      .json({ error: "An error occurred while setting the active workspace." });
  }
};

// Controller to get the All workspace
const getAllWorkspaces = async (req, res) => {
  try {
    const user_id = req.user.id;
    // console.log("User ID from token:", user_id);


    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 8;
    const skip = (page - 1) * limit;

    const totalDocuments = await Workspace.countDocuments({ user_id: user_id });
    const workspaces = await Workspace.find({ user_id })
    .skip(skip)
    .limit(limit)
    .sort({ createdAt: -1 });

    if (workspaces.length === 0) {
      return res
        .status(200)
        .json({ error: "No workspaces found for this user." });
    }

    res.status(200).json({
      success: true,
      message: "Workspaces fetched successfully",
      workspaces,
      pagination: {
        totalDocuments,
        totalPages: Math.ceil(totalDocuments / limit),
        currentPage: page,
        limit,
      },
    });
  } catch (error) {
    console.error("Error retrieving workspace data:", error.stack || error);
    res
      .status(500)
      .json({ error: "An error occurred while retrieving workspace data" });
  }
};

//Controller for Delete Workspace by Slug As well As Pal Workspace
// const deleteWorkspace = async (req, res) => {
//   try {
//     // Extract user_id from the authenticated user
//     const user_id = req.user.id;
//     const { slug } = req.params;

//     const workspace = await Workspace.findOneAndDelete({
//       user_id,
//       workspace_slug: slug,
//     });
//     if (!workspace) {
//       return res.status(200).json({
//         success: false,
//         message: "Workspace not found for this user.",
//       });
//     }
//     // Call the external API to delete the workspace
//     const externalApiUrl = `${BASE_URL}/${slug}`;
//     await axios.delete(`${BASE_URL}/${slug}`);
//     return res
//       .status(200)
//       .json({ success: true, message: "Workspace deleted successfully." });
//   } catch (error) {
//     console.error("Error deleting workspace:", error);
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

//  Controller for Delete Workspace by Slug As well As Pal Workspace
const deleteWorkspace = async (req, res) => {
  try {
    const user_id = req.user.id;

    const { slug } = req.params;
    const workspace = await Workspace.findOne({
      user_id,
      workspace_slug: slug,
    });
    if (!workspace) {
      return res.status(404).json({
        success: false,
        message: "Workspace not found for this user.",
      });
    }
    if (workspace.status === "active") {
      return res.status(400).json({
        success: false,
        message: "Active workspaces cannot be deleted.",
      });
    }

    await workspace.deleteOne();
    const externalApiUrl = `${BASE_URL}/${slug}`;
    await axios.delete(externalApiUrl);

    return res.status(200).json({
      success: true,
      message: "Workspace deleted successfully.",
    });
  } catch (error) {
    console.error("Error deleting workspace:", error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Controller for Updating Workspace
const updateWorkspaceAndDocument = async (req, res) => {
  try {
    const { productName } = req.body;
    const productImage = req.files?.productImage?.[0];
    const { slug } = req.params;

    // console.log("Received data: ", { productName });
    // console.log("Received files: ", { productImage });
    // console.log("Workspace slug from params: ", workspaceSlug);

    const workspace = await Workspace.findOne({
      workspace_slug: slug,
    });
    if (!workspace) {
      return res.status(404).json({ error: "Workspace not found" });
    }
    if (!productName && !productImage) {
      console.log("Error: Missing required fields.");
      return res.status(400).json({
        error: "Either product name or product image is required for update.",
      });
    }
    let imageBlobData = null;
    if (productImage) {
      imageBlobData = await uploadFileToBlob(productImage, "images");
    }
    if (productName) {
      workspace.product_name = productName;
    }
    if (imageBlobData) {
      workspace.product_image = imageBlobData.url;
    }
    await workspace.save();
    res.status(200).json({
      success: true,
      message: "Product details updated successfully.",
      updatedWorkspace: workspace,
    });
  } catch (error) {
    console.error("Error while updating product details:", error);
    res.status(500).json({
      error: "An error occurred during the update process.",
    });
  }
};

const getActiveWorkspaceLogo = async (req, res) => {
  try {
    const user_id = req.user.id;

    const user = await User.findOne({ _id: user_id }).select("name email");
    if (!user) {
      throw new CustomError("User not found", 400);
    }

    const activeWorkspace = await Workspace.findOne({
      user_id,
      status: "active",
    }).select("product_name product_image workspace_name");

    if (!activeWorkspace) {
      return res.status(404).json({
        message: "No active workspaces found for this user.",
      });
    }

    res.status(200).json({
      success: true,
      message: "Active workspace retrieved successfully.",
      workspace_name: activeWorkspace.workspace_name,
      product_name: activeWorkspace.product_name || "No product name available",
      product_image:
        activeWorkspace.product_image || "No product image available",
      userName: user.name,
      userEmail: user.email,
    });
  } catch (error) {
    console.error("Error fetching active workspaces:", error);
    return res.status(500).json({
      error: "An error occurred while fetching active workspaces.",
    });
  }
};

const workspaceQA = async (req, res) => {
  const { slug } = req.params;
  const { question, answer } = req.body;

  if (!question || !answer) {
    return res
      .status(400)
      .json({ success: false, message: "Question and answer are required." });
  }

  try {
    const workspace = await Workspace.findOne({ workspace_slug: slug });

    if (!workspace) {
      return res
        .status(404)
        .json({ success: false, message: "Workspace not found." });
    }

    // Add the new question-answer pair to the workspace
    workspace.questionsAndAnswers.push({ question, answer });
    await workspace.save();

    res.status(200).json({
      success: true,
      message: "Question and answer updated successfully.",
      data: workspace.questionsAndAnswers,
    });
  } catch (error) {
    console.error("Error updating workspace:", error);
    res.status(500).json({ success: false, message: "Internal server error." });
  }
};

// const getWorkspaceQA = async (req, res) => {
//   try {

//     const userId = req.user.id;
//     const page = parseInt(req.query.page) || 1;
//     const limit = parseInt(req.query.limit) || 10;
//     const skip = (page - 1) * limit;

//     if (!userId) {
//       return res.status(404).json({
//         success: false,
//         message: "User not found.",
//       });
//     }

//     const workspace = await Workspace.find({ user_id: userId })
//       .select("workspace_name workspace_slug chat")
//       .skip(skip)
//       .limit(limit)
//       .lean();


//     const totalDocuments = await Workspace.countDocuments({ user_id: userId });
//     const totalPages = Math.ceil(totalDocuments / limit);

//     if (!workspace || workspace.length === 0) {
//       return res.status(404).json({
//         success: false,
//         message: "No workspace found for the user.",
//       });
//     }

//     return res.status(200).json({
//       success: true,
//       message: "Workspaces retrieved successfully.",
//       data: workspace,
//       pagination: {
//         totalDocuments,
//         totalPages,
//         currentPage: page,
//         limit,
//       },
//     });
//   } catch (error) {
//     console.error("Error fetching workspace Q&A:", error);
//     return res.status(500).json({
//       success: false,
//       message: "Internal server error.",
//     });
//   }
// };

module.exports = {
  createWorkspaceAndUploadPDF,
  uploadEmbeddingLink,
  getAllWorkspaces,
  getWorkspaceNameById,
  parserPdfUpload,
  deleteWorkspace,
  updateWorkspaceAndDocument,
  getActiveWorkspaces,
  setActiveWorkspace,
  workspaceCreated,
  getActiveWorkspaceLogo,
  workspaceQA,
  // getWorkspaceQA,
};
