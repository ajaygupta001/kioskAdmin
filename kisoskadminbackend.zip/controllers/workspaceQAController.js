require("dotenv").config();
const QuestionAnswer = require("../models/Question.js");
// const Workspace = require("../models/workspace.js");
const User = require("../models/user.js");

// Base URL for API
const BASE_URL = process.env.BASE_URL;

// Create Workspace with QA
// const createWorkspaceQA = async (req, res) => {
//   try {
//     const { workspaceName, createdBy, product, questionsAndAnswers } = req.body;

//     // Find user by username
//     const user = await User.findOne({ name: createdBy });
//     if (!user) {
//       return res.status(404).json({ message: "User not found." });
//     }

//     // const user_id = req.user.id;
//     // let workspaceList = await Workspace.find({ user_id });
//     // let statusToUpdate = workspaceList.length > 0 ? true : false;

//     // return res.status(200).json({
//     //   WorkspaceCreated: statusToUpdate,
//     // });

//     // Create a new workspace with the user's ObjectId
//     const newWorkspace = new WorkspaceQuestion({
//       workspaceName,
//       createdBy: user._id, // Use the user's ObjectId
//       product,
//       questionsAndAnswers,
//     });

//     // Save to the database
//     const savedWorkspace = await newWorkspace.save();
//     console.log("Workspace created:", savedWorkspace);

//     res.status(201).json({
//       message: "Workspace created successfully.",
//       workspace: savedWorkspace,
//     });
//   } catch (error) {
//     console.error("Error creating workspace:", error);
//     res.status(500).json({
//       message: "Failed to create workspace.",
//       error: error.message,
//     });
//   }
// };

const createWorkspaceQA = async (req, res) => {
  try {
    const { workspaceName, workspaceSlug, questionsAndAnswers } = req.body;

    // Validate required fields
    if (!workspaceName || !workspaceSlug) {
      return res
        .status(400)
        .json({ message: "Workspace name and slug are required." });
    }

    // Get user info from the token
    const userId = req.user._id;

    // Check if the user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // Create a new workspace
    const newWorkspace = new WorkspaceQuestion({
      workspaceName,
      workspaceSlug,
      createdBy: userId,
      questionsAndAnswers,
    });

    const savedWorkspace = await newWorkspace.save();
    res.status(201).json({
      message: "Workspace created successfully.",
      workspace: savedWorkspace,
    });
  } catch (error) {
    console.error("Error creating workspace:", error);
    res.status(500).json({
      message: "Failed to create workspace.",
      error: error.message,
    });
  }
};

const getWorkspaceQA = async (req, res) => {
  try {
    const userId = req.user.id;

    if (!userId) {
      console.log("User ID is missing in req.user.");
      return res
        .status(401)
        .json({ message: "Unauthorized: User ID missing." });
    }

    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const user = await User.findById(userId);

    if (!user) {
      console.log("User not found in DB.");
      return res.status(404).json({ message: "User not found." });
    }

    // Get filter, search, and sort parameters
    const {  sortField = "date", sortOrder = "desc" } = req.query;

    // const searchQuery = search
    //   ? { workspaceSlug: { $regex: search, $options: "i" } }
    //   : {};

    const sortCriteria = {};
    sortCriteria[sortField] = sortOrder === "desc" ? -1 : 1;

    const workspaces = await QuestionAnswer.find({
      userId: userId,
      // ...searchQuery,
    })
      //  .select("workspaceName workspaceSlug question answer time date")
      .skip(skip)
      .limit(limit)
      .sort(sortCriteria)
      .lean();

    const totalDocuments = await QuestionAnswer.countDocuments({
      userId: userId,
    });
    const totalPages = Math.ceil(totalDocuments / limit);

    if (!workspaces || workspaces.length === 0) {
     
      return res.status(404).json({
        success: false,
        message: "No Chats found for the user.",
      });
    }

    return res.status(200).json({
      success: true,
      message:
        "Workspace chat Question and Answer Data retrieved successfully.",
      data: workspaces,
      pagination: {
        totalDocuments,
        totalPages,
        currentPage: page,
        limit,
      },
    });
  } catch (error) {
    console.error("Error in getWorkspaceQA:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
};




const deleteWorkspaceQA = async(req,res)=>{
  try {

    const userId = req.user.id;
    const {workspaceQAId} = req.params;

    if (!userId) {
      console.log("User ID is missing in req.user.");
      return res
        .status(401)
        .json({ message: "Unauthorized: User ID missing." });
    }
    const user = await User.findById(userId);

    if (!user) {
      console.log("User not found in DB.");
      return res.status(404).json({ message: "User not found." });
    }

    const deletedWorkspaceQA = await QuestionAnswer.findByIdAndDelete(workspaceQAId);

    if (!deletedWorkspaceQA) {
      return res.status(404).json({
        success: false,
        message: "No workspace chat found with this ID.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Workspace chat Question and Answer deleted successfully.",
      // data: deletedWorkspaceQA,
    });

    
  } catch (error) {
    console.error("Error in deleteWorkspaceQA:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
}

// Update Product Details
const updateProductDetails = async (req, res) => {
  try {
    const { workspaceId, newDetails } = req.body;

    const updatedWorkspace = await WorkspaceQuestion.findByIdAndUpdate(
      workspaceId,
      {
        "product.details": newDetails,
        updatedAt: Date.now(), // Update the timestamp
      },
      { new: true }
    );

    if (!updatedWorkspace) {
      return res.status(404).json({ message: "Workspace not found." });
    }

    res.status(200).json({
      message: "Product details updated successfully.",
      workspace: updatedWorkspace,
    });
  } catch (error) {
    console.error("Error updating product details:", error);
    res.status(500).json({
      message: "Failed to update product details.",
      error: error.message,
    });
  }
};

// Update Workspace Questions
const updateWorkspaceQA = async (req, res) => {
  try {
    const { workspaceId, question, answer, time } = req.body;

    const updatedWorkspace = await WorkspaceQuestion.findByIdAndUpdate(
      workspaceId,
      {
        $push: {
          questionsAndAnswers: { question, answer, time },
        },
        updatedAt: Date.now(), // Update the timestamp
      },
      { new: true }
    );

    if (!updatedWorkspace) {
      return res.status(404).json({ message: "Workspace not found." });
    }

    res.status(200).json({
      message: "Workspace updated successfully.",
      workspace: updatedWorkspace,
    });
  } catch (error) {
    console.error("Error updating workspace:", error);
    res.status(500).json({
      message: "Failed to update workspace.",
      error: error.message,
    });
  }
};

module.exports = {
  createWorkspaceQA,
  updateProductDetails,
  updateWorkspaceQA,
  getWorkspaceQA,
  deleteWorkspaceQA,
};
