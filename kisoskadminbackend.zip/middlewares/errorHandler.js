// Custom Error Handler Middleware
const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || 500;

  // Log the error stack based on the environment
  if (process.env.NODE_ENV === "development") {
    console.error("Development Error Stack:", err.stack);
  } else if (process.env.NODE_ENV === "production") {
    console.error("Production Error Message:", err.message); // Log message only in production
  }

  res.status(statusCode).json({
    success: false,
    message: err.message || "Server Error",
  });
};

// Custom Error Class for creating specific error types
class CustomError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    // Capture the stack trace where the error occurred
    Error.captureStackTrace(this, this.constructor);
  }
}

const pageNotFound = (req, res) => {
  res.status(404).json({
    success: false,
    error: "Route Not Found",
    message: `The requested route '${req.originalUrl}' does not exist on this server.`,
  });
};


// Export both the errorHandler middleware and CustomError class
module.exports = { errorHandler, CustomError,pageNotFound };
