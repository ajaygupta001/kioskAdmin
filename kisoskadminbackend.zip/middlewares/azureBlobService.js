const { BlobServiceClient } = require("@azure/storage-blob");
const { v1: uuidv1 } = require("uuid");
const fs = require("fs");
const path = require("path");
const User = require("../models/user");
const Avatar = require("../models/avatar.js");

//PalDev
const AZURE_STORAGE_CONNECTION_STRING =
  process.env.AZURE_STORAGE_CONNECTION_STRING;
const blobServiceClient = BlobServiceClient.fromConnectionString(
  AZURE_STORAGE_CONNECTION_STRING
);
const containerName = process.env.AZURE_STORAGE_NAME;
const containerClient = blobServiceClient.getContainerClient(containerName);

//SaasDev
const AZURE_STORAGE_CONNECTION_STRING_SAS =
  process.env.AZURE_STORAGE_CONNECTION_STRING_SAS;
const blobServiceClientSas = BlobServiceClient.fromConnectionString(
  AZURE_STORAGE_CONNECTION_STRING_SAS
);
const containerNameSAS = process.env.AZURE_STORAGE_NAME_SAS;
const containerClientSas =
  blobServiceClientSas.getContainerClient(containerNameSAS);
console.log("Using Connection String:", AZURE_STORAGE_CONNECTION_STRING_SAS);
console.log("Container Name:", containerNameSAS);

async function streamToBuffer(readableStream) {
  const chunks = [];
  for await (const chunk of readableStream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function getFileMiddleware(req, res, next) {
  const url = req.query.url; // Retrieve the URL from query parameter

  if (!url || url.length === 0) {
    return res.status(400).json({ error: "url is required" });
  }

  try {
    const blockBlobClient = containerClientSas.getBlockBlobClient(url);
    const downloadBlockBlobResponse = await blockBlobClient.download(0);
    const downloadedBuffer = await streamToBuffer(
      downloadBlockBlobResponse.readableStreamBody
    );

    const base64Data = Buffer.from(downloadedBuffer).toString("base64").trim();
    res.locals.base64File = base64Data;

    next();
  } catch (error) {
    console.error("Error downloading blob:", error);
    res
      .status(500)
      .json({ error: "Failed to download file from Azure Blob Storage" });
  }
}

async function createContainerIfNotExists() {
  const exists = await containerClient.exists();
  if (!exists) {
    await containerClient.create();
    console.log(`Container ${containerName} created.`);
  }
}

// Upload file to Azure Blob Storage
async function uploadFileToBlob(file) {
  await createContainerIfNotExists();
  const blobName = `files/${uuidv1()}-${file.originalname}`;
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);
  const uploadBlobResponse = await blockBlobClient.uploadData(file.buffer);
  return {
    blobName,
    url: blockBlobClient.url,
  };
}

async function getFile(fileName) {
  try {
    const containerClient = blobServiceClient.getContainerClient(containerName);
    const blockBlobClient = containerClient.getBlockBlobClient(fileName);
    const blobDownload = await blockBlobClient.download();
    return blobDownload.readableStreamBody;
  } catch (error) {
    console.error("Error downloading file:", error.message);
    throw error;
  }
}

async function uploadAvatarZip(avatarName, filePath) {
  await createContainerIfNotExists();
  const blobName = `${avatarName}.zip`;
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);
  await blockBlobClient.uploadFile(filePath);
  return {
    blobName,
    url: blockBlobClient.url,
  };
}

module.exports = {
  uploadAvatarZip,
  uploadFileToBlob,
  getFile,
  containerClient,
  streamToBuffer,
  createContainerIfNotExists,
  getFileMiddleware,
};
