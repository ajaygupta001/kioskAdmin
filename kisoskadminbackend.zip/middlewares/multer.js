const multer = require("multer");
const path = require("path");
const fs = require("fs").promises;

const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    fileFilter: (req, file, cb) => {
      if (file.fieldname === "pdfFile" && file.mimetype === "application/pdf") {
        cb(null, true);
      } else if (
        file.fieldname === "productImage" &&
        file.mimetype.startsWith("image/")
      ) {
        cb(null, true);
      } else {
        cb(new Error("Invalid file type"), false);
      }
    },
  });


 
  



module.exports =  upload ;
