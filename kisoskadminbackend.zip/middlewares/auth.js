const adminOnly = (req, res, next) => {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ message: "Access Denied: Admins only" });
  }
  next();// Proceed if admin 
};


const userOnly = (req, res, next) => {
  if (req.user && !req.user.isAdmin) {
    next(); // Proceed if user
  } else {
    return res.status(403).json({ message: "Access denied. Users only." });
  }
};

module.exports = {adminOnly,userOnly};

