// middleware/validateApiKey.js
const validApiKey = (req, res, next) => {
  const apiKey = req.headers["x-api-key"];
  const validApiKeys = ["H491K3P-T5YMG65-JAR7G21-G5KY9NW"];
  if (!apiKey) {
    return res.status(401).json({ error: "API key is missing" });
  }
  if (!validApiKeys.includes(apiKey)) {
    return res.status(403).json({ error: "Invalid API key" });
  }

  req.apiKey = apiKey;
  next();
};

module.exports = validApiKey;
