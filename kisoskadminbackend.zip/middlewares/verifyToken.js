const jwt = require("jsonwebtoken");
const User = require("../models/user.js");

const JWT_SECRET = process.env.JWT_SECRET || "H491K3P-T5YMG65-JAJAY21-G5KY9NW";
const ADMIN_JWT_SECRET =
  process.env.ADMIN_JWT_SECRET || "AJAYK3P-T5YMAJ75-JAR7G21-HYTEN04W";

// Middleware to verify the JWT token
const verifyToken = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1]|| req.cookies.token  ;

  if (!token) {
    return res.status(403).json({ message: "No token provided." });
  }


  try {
    //console.log("token",token);
    const decoded = jwt.verify(token, ADMIN_JWT_SECRET); // Check for admin
    const user = await User.findById(decoded.userid);
    //  console.log("admin----",decoded.userid);
   

    if (!user) {
      console.log("User not found in DB");
      return res.status(404).json({ error: "User not found" });
    }
    
    req.user = user;
   
    //req.user = decoded;
    req.user.isAdmin = true;
    // console.log("Verified Admin User ID:", req.user.id);
    next();
  } catch (adminError) {
    try {
      const decoded = jwt.verify(token, JWT_SECRET); // Check for user

      const user = await User.findById(decoded.userid);

      if (!user) {
        console.log("User not found in DB");
        return res.status(404).json({ error: "User not found" });
      }
      req.user = user;
      //req.user = decoded;
      req.user.isAdmin = false;
      // console.log("Verified Regular User ID:", req.user.id);
      next();
    } catch (userError) {
      return res.status(401).json({ message: "Unauthorized." });
    }
  }
};

module.exports = verifyToken;
