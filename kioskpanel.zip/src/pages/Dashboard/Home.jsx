import React from 'react';
import Sidebar from '@/components/Sidebar/Sidebar';
import MainContent from '@/components/Maincontent/dashboard';

const Home = () => {
  return (
    <div className="flex">
       
       <MainContent />
   
      
    </div>
  );
};

export default Home;
