// // import VrmViewer from "./components/vrmViewer/vrmViewer";
// import { useSelector } from "react-redux";
// import Restrodetail from "../components/window/restrodetails";

// import Leftdetails from "@components/window/leftdetails";
// import Rightdetails from "@components/window/rightdetails";
// function Detailspage() {
//   const showRestoDetail = useSelector((state) => state.details.review);

//   return (
//     <div className="flex-col h-full w-full">
//       <div className="absolute top-[10%] flex justify-between mb-5 h-[78%] w-full z-10">
//         <Leftdetails />
//         {showRestoDetail ? <Restrodetail /> : <Rightdetails />}
//       </div>
//     </div>
//   );
// }

// export default Detailspage;
