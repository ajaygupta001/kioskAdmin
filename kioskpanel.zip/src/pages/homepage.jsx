// import LeftPanel from "@components/window/left";
// import RightPanel from "@components/window/right";
// function Homepage() {
//   return (
//     <div className="flex-col h-full w-full">
//       <div className="absolute top-[10%] flex justify-between mb-5 h-[78%] w-full">
//         <LeftPanel />
//         <RightPanel />
//       </div>
//     </div>
//   );
// }

// export default Homepage;
