import { useState } from 'react';
import JSZip from 'jszip';

export default function FileUploader() {
  const [fileData, setFileData] = useState(null);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    
    if (!file) {
      console.error("No file selected.");
      return;
    }

    const reader = new FileReader();

    reader.onload = async function(event) {
      const bytes = new Uint8Array(event.target.result);
      const zipSignature = [0x50, 0x4B]; // ZIP file signature (PK)

      // Log the first few bytes of the file
      console.log("First 4 bytes of the file:", bytes.slice(0, 4));

      // Check if the first two bytes match the ZIP signature
      if (bytes[0] === zipSignature[0] && bytes[1] === zipSignature[1]) {
        console.log("This is a valid ZIP file.");
        
        try {
          const zip = new JSZip();
          const unzipped = await zip.loadAsync(event.target.result);

          const files = Object.keys(unzipped.files);
          console.log("Unzipped files:", files);

          // Example: Extract the first file and display its content (assuming it's an image)
          const firstFileName = files[0];
          const fileContent = await unzipped.file(firstFileName).async('base64');

          setFileData(`data:image/jpeg;base64,${fileContent}`);
          // You can also cache the file content in localStorage for later use
          localStorage.setItem(firstFileName, fileContent);

        } catch (error) {
          console.error("Error reading ZIP file:", error);
        }
      } else {
        console.error("This file is not a valid ZIP file.");
      }
    };

    reader.readAsArrayBuffer(file); // Read the file as ArrayBuffer
  };

  const loadCachedFile = () => {
    // Load the first cached file (for example purposes)
    const cachedFile = localStorage.getItem(Object.keys(localStorage)[0]);
    if (cachedFile) {
      setFileData(`data:image/jpeg;base64,${cachedFile}`); // assuming image type
    } else {
      console.log('No file cached');
    }
  };

  return (
    <div>
      <input type="file" onChange={handleFileUpload} />
      <button onClick={loadCachedFile}>Load Cached File</button>

      {fileData && <img src={fileData} alt="Cached File" />}
    </div>
  );
}
