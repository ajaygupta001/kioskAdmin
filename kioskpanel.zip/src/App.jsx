import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import "./index.css";
import Maincontent from "./components/Maincontent/MainContent";
import Sidebar from "./components/Sidebar/Sidebar";
import Home from "./pages/Dashboard/Home";
import CreateDashboard from './components/Maincontent/CreateDashboard';
import Pal from "./components/Maincontent/Pal";
import Products from "./components/Settings/Products";
import Product from "./components/Product";
import Profile from "./components/Profile/profile";
// import Editpal from "./components/Maincontent/Editpal";
import Login from "./components/Login/Login";
import Signup from "./components/Login/Signup";
import Resetpassword from "./components/Login/Resetpassword";
import Createpassword from "./components/Login/Createpassword";
import PrivateRoute from "./components/PrivateRoute";
import Dashboard from "./pages/Dashboard/Home";

function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/resetpassword" element={<Resetpassword />} />
        <Route path="/createpassword" element={<Createpassword />} />

        {/* Private routes */}
        <Route
  path="/Dashboard"
  element={
    <PrivateRoute>
      <Dashboard />
    </PrivateRoute>
  }
/>
        <Route
          path="/products"
          element={
            <PrivateRoute>
              <Products/>
            </PrivateRoute>
          }
        />
         <Route
          path="/product"
          element={
            <PrivateRoute>
              <Product/>
            </PrivateRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <PrivateRoute>
              <Profile />
            </PrivateRoute>
          }
        />
        <Route
          path="/createdashboard"
          element={
            <PrivateRoute>
              <CreateDashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/pal"
          element={
            <PrivateRoute>
              <Pal />
            </PrivateRoute>
          }
        />
        {/* <Route
          path="/editpal"
          element={
            <PrivateRoute>
            </PrivateRoute>
          }
        /> */}
        {/* <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        /> */}

        {/* Other components */}
        <Route path="/maincontent" element={<Maincontent />} />
        <Route path="/sidebar" element={<Sidebar />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
