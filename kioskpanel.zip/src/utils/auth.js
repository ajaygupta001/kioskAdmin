export const isAuthenticated = () => {
  const token = localStorage.getItem('authToken');
  return !!token; 
};


export const getAuthToken = () => {
  return localStorage.getItem('authToken');
};
