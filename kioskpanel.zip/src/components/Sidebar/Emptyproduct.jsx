import React, { useEffect, useState } from "react";
import dashboard from "@assets/dashboard.png";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";
import CreateDashboard from "../Maincontent/CreateDashboard";

const MainContent = ({ workspaceActive }) => {
  const navigate = useNavigate();
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const isAuthenticated = () => {
    const token = localStorage.getItem("authToken");
    return !!token;
  };

  useEffect(() => {
    if (!isAuthenticated()) {
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    if (workspaceActive) {
      console.log("Workspace is active");
    }
  }, [workspaceActive]);

  const togglePopup = () => {
    setIsPopupOpen(!isPopupOpen);
  };

  return (
    <div className="bg-purple-50 min-h-screen p-4">

    <div className="p-4 rounded-lg mb-4 mx-auto w-full max-w-lg">
     
    </div>
  
    {/* Main Content */}
 
  
    {/* Create Product Section */}
    <div className="relative mt-10 w-full max-w-lg mx-auto">
      <div className="flex flex-col items-center bg-white p-6 rounded-xl shadow-sm">
        <p className="text-lg text-[#48464C] font-medium mb-2">Create your Product</p>
        <p className="text-sm md:text-base text-[#6D6D6D] font-normal font-['Poppins'] text-center">
          You have no active Product on your account, Create one!
        </p>
        <button
          onClick={togglePopup}
          className="mt-4 bg-[#7D3AFC] text-white h-12 w-40 lg:h-14 lg:w-64 rounded-lg flex items-center justify-center"
        >
          <img src={dashboard} alt="Create Icon" className="w-5 h-5 mr-2" />
          Create
        </button>
      </div>
    </div>
  
    {/* Popup */}
    {isPopupOpen && (
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
        <div>
          <CreateDashboard setIsPopupOpen={setIsPopupOpen} isPopupOpen={isPopupOpen} />
        </div>
      </div>
    )}
  </div>
  
  );
};

export default MainContent;
