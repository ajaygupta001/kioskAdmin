import React,{useState} from "react";
// import dashboard from "@assets/dashboard.png";
// import dashboard1 from "@assets/dashboard1.png";
import home from "@assets/home.png";
import home1 from "@assets/home1.png";
import setting from "@assets/setting.png";
import setting1 from "@assets/setting1.png";
import profile from "@assets/profile.png";
import profile3 from "@assets/profile3.png";
import products from "@assets/products.png";
import pallogo from "@assets/pallogo.png";
import products1 from "@assets/products1.png";
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const isActive = (path) => location.pathname === path;

  const NavLink = ({ to, icon, activeIcon, children }) => (
    <Link
      to={to}
      className={`flex items-center px-8 py-2 rounded-[18.46px] ${
        isActive(to)
          ? 'text-white bg-[#7D3AFC]'  // Active state
          : 'text-[#7D3AFC] hover:bg-purple-100 hover:text-purple-700' // Inactive state with text color #7D3AFC
      } transition-colors duration-200`}
    >
      {/* <img
        src={isActive(to) ? activeIcon : icon}
        alt={`${children} Icon`}
        className="w-6 h-6"
      /> */}
      <span className="ml-2">{children}</span>
    </Link>
  );
  
  
  


  return (
  
      <div className="  px-4">
     <div className="flex justify-between bg-[#FFFFFF] w-[18rem] h-[2.5rem] mt-[4.62px] rounded-[18.46px] border border-[0.5px] border-gray-300">   {/* Logo Section */}
         

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <NavLink 
              to="/dashboard"
             
             
            >
              Dashboard
            </NavLink>
            <NavLink 
              to="/product"
             
            >
              Products
            </NavLink>
            {/* <NavLink 
              to="/profile"
              icon={profile}
              activeIcon={profile3}
            >
              Profile
            </NavLink> */}
          </div>

          {/* Mobile Menu Button */}
          <div
  className="md:hidden flex items-center w-[4rem] h-[6rem] mt-[8.08px] ml-[3.46px] rounded-lg "
>
  <button
    onClick={() => setIsOpen(!isOpen)}
    className="inline-flex items-center justify-center p-2 rounded-md text-purple-600 hover:bg-purple-100 "
  >
    {isOpen ? (
      <X className="h-8 w-10" />
    ) : (
      <Menu className="h-6 w-10" />
    )}
  </button>
</div>

        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <NavLink 
                to="/dashboard"
               
              >
                Dashboard
              </NavLink>
              <NavLink 
                to="/product"
              
              >
                Products
              </NavLink>
              <NavLink 
                to="/profile"
                icon={profile}
                activeIcon={profile3}
              >
                Profile
              </NavLink>
            </div>
          </div>
        )}
      </div>

  );
};

export default Navbar;
