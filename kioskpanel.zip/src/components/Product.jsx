import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar/Sidebar";
import Saloon from "@assets/Saloon.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getAuthToken } from "/src/utils/auth";
import edit2 from "@assets/edit2.png";
import deleteIcon from "@assets/delete.png";
import dashboard from "@assets/dashboard.png";
import CreateDashboard from "../components/Maincontent/CreateDashboard";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Emptyproduct from "../components/Sidebar/Emptyproduct";
import Navbar from "./Login/Navbar";
import Palcard from "../components/Settings/Palcard";
import Palline from "@assets/Palline.png";

const Tooltip = ({ text, fullText }) => {
  const [isTooltipVisible, setIsTooltipVisible] = useState(false);

  const truncateText = (text, wordLimit = 10) => {
    const words = text.split(" ");
    return words.length > wordLimit
      ? words.slice(0, wordLimit).join(" ") + "..."
      : text;
  };

  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setIsTooltipVisible(true)}
      onMouseLeave={() => setIsTooltipVisible(false)}
    >
      <span className="cursor-help border-b border-dotted">
        {truncateText(text, 10)}
      </span>
      {isTooltipVisible && (
        <div className="absolute z-10 p-4 bg-[#E7E5FE] w-[14rem] text-[#333333] text-sm rounded shadow-lg bottom-full left-1/2 transform -translate-x-1/2 -translate-y-1">
          {fullText}
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-x-8 border-t-8 border-x-transparent border-t-black"></div>
        </div>
      )}
    </div>
  );
};

const DashboardContent = () => {
  const navigate = useNavigate();
  const [workspaces, setWorkspaces] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [currentEditWorkspace, setCurrentEditWorkspace] = useState(null);

  useEffect(() => {
    const fetchWorkspace = async () => {
      try {
        const token = getAuthToken();
        if (!token) {
          throw new Error("No authentication token found. Please log in.");
        }

        const response = await axios.get(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/get`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (
          response.status === 200 &&
          Array.isArray(response.data.workspaces)
        ) {
          const enrichedWorkspaces = response.data.workspaces.map(
            (workspace) => ({
              ...workspace,
              isDeletable: response.status === 200,
            })
          );
          setWorkspaces(enrichedWorkspaces);
        } else {
          setError("No workspaces found or invalid response format.");
        }

        // setLoading(false);
      } catch (err) {
        const errorMessage = err?.response?.data?.message || err.message;
        setError(errorMessage);
        console.error("Error fetching workspace data:", err);
        // setLoading(false);
      }
    };

    fetchWorkspace();
  }, [navigate]);

  const fetchWorkspaceById = async (workspaceId) => {
    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("No authentication token found. Please log in.");
      }

      const response = await axios.get(
        `${
          import.meta.env.VITE_BACKEND_URL
        }/api/v1/workspace/getWorkspaceNameById/${workspaceId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.status === 200 && response.data) {
        setCurrentEditWorkspace(response.data);
        setIsPopupOpen(true);
      } else {
        toast.error("Failed to fetch workspace details.");
      }
    } catch (err) {
      console.error("Error fetching workspace details:", err);
      toast.error(
        err.response?.data?.message || "Error fetching workspace details."
      );
    }
  };
  const handleWorkspaceUpdated = (updatedWorkspace) => {
    setWorkspaces((prevWorkspaces) =>
      prevWorkspaces.map((workspace) =>
        workspace.slug === updatedWorkspace.slug ? updatedWorkspace : workspace
      )
    );
  };

  const handleEditClick = (workspace) => {
    fetchWorkspaceById(workspace.workspace_id);
  };

  const handleDelete = async (slug) => {
    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("No authentication token found. Please log in.");
      }

      const response = await axios.delete(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/${slug}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.status === 200) {
        setWorkspaces((prevWorkspaces) =>
          prevWorkspaces.filter(
            (workspace) => workspace.workspace_slug !== slug
          )
        );
        toast.success("Workspace deleted successfully!");
      }
    } catch (err) {
      console.error("Error deleting workspace:", err);
      toast.error(
        err.response?.data?.message || "Failed to delete the workspace."
      );
    }
  };

  const togglePopup = () => {
    setIsPopupOpen(!isPopupOpen);
    if (!isPopupOpen) setCurrentEditWorkspace(null);
  };

  return (
    <div className="flex flex-col xl:flex-row min-h-screen items-start justify-start">
      <div className="flex-1 bg-purple-50 h-screen  ">
        <Navbar />

        <div className=" mt-[1rem] ml-[48rem]">
          <Sidebar />
        </div>
        <Palcard />

        <div className=" ml-[98rem] mt-[2rem]">
          <button
            onClick={togglePopup}
            className="bg-[#7D3AFC] text-white h-[3rem] w-[11rem] rounded-[10px] flex items-center justify-center font-poppins font-medium text-[16px] leading-[24px] space-x-2"
            style={{ position: "relative", top: "6px", left: "38px" }}
          >
            <img
              src={dashboard}
              alt="Create Icon"
              className="w-[20px] h-[20px]"
            />
            <span class="font-poppins font-medium text-[14px] leading-[24px]">
              Add New Product
            </span>
          </button>
        </div>
        <div className="flex items-center justify-between  ml-20 mt-[-2rem] ">
          <span className="font-poppins font-medium text-[20px] whitespace-nowrap  mr-[2rem]">
            Inactive Products
          </span>

          <img
            src={Palline}
            alt="Create Icon"
            className="mr-[36rem] w-[70rem] " 
          />
        </div>

        {/* Popup Section */}
        {isPopupOpen && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <CreateDashboard
              workspace={currentEditWorkspace}
              setIsPopupOpen={setIsPopupOpen}
              onClose={togglePopup}
              onWorkspaceUpdated={handleWorkspaceUpdated}
            />
          </div>
        )}

        {workspaces.length === 0 ? (
          <Emptyproduct />
        ) : (
          <div className="grid grid-cols-1 ml-20 mt-[5rem] sm:grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-4 md:gap-6 lg:gap-8 xl:gap-8">
            {workspaces.map((workspace, index) => (
              <div
                key={index}
                className="w-[23rem] h-[6.5rem] bg-[#E7E5FE] rounded-lg shadow-lg flex relative p-4"
              >
                <div className="absolute top-4 right-4 flex space-x-2">
                  <button
                    onClick={() => handleDelete(workspace.workspace_slug)}
                    disabled={!workspace.isDeletable}
                    className4={`relative w-9 h-9 ${
                      !workspace.isDeletable
                        ? "opacity-50 cursor-not-allowed"
                        : ""
                    }`}
                  >
                    <img
                      src={deleteIcon}
                      alt="Delete"
                      className="w-[2rem] h-[1.5rem]"
                    />
                  </button>
                  <button onClick={() => handleEditClick(workspace)}>
                    <img
                      src={edit2}
                      alt="Edit"
                      className="w-[1.5rem] h-[1.5rem]  "
                    />
                  </button>
                </div>
               <div className="w-10 h-10 sm:w-20 sm:h-20 rounded-full border-2 border-[#FFFFFF] overflow-hidden flex-shrink-0 ml-2 flex items-center justify-center">
                               <img
                src={workspace.product_image || Saloon}
                alt="Product"
                className="max-w-full max-h-full object-contain w-[6rem] h-[6rem]"
               />
               </div>

                <div className="ml-3">
                  <h4 className="text-lg text-[#333333] font-medium mb-1">
                    {workspace.product_name}
                  </h4>
                  <p className="text-sm text-[#333333] mb-4 max-w-xs text-center sm:text-left">
                    <Tooltip
                      text={
                        workspace.product_info ||
                        "Discover the best in beauty and wellness with our easy-to-use salon app."
                      }
                      fullText={
                        workspace.product_info ||
                        "Discover the best in beauty and wellness with our easy-to-use salon app."
                      }
                    />
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Toast Notifications */}
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
        />
      </div>
    </div>
  );
};

export default DashboardContent;
