import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Image2 from "@assets/image.png.png";
import girl1 from "@assets/girl1.png.png";
import girl2 from "@assets/girl2.png.png";
import dashboard from "@assets/dashboard.png";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const MainContent = () => {
  const navigate = useNavigate();

  // Example of checking if a user is authenticated
  useEffect(() => {
    const isAuthenticated = false; // Replace this with your actual authentication check

    if (!isAuthenticated) {
      navigate('/login'); // Redirect to the login page if not authenticated
    }
  }, [navigate]);

  const handleCreateClick = () => {
    navigate('/createDashboard'); // Navigate to the "/createDashboard" route
  };

  return (
    <div className="flex-1 bg-purple-50 p-8">
 
     
      {/* Existing Content */}
      <div className="max-w-7xl p-3 rounded-lg mx-auto bg-purple-100 flex justify-between items-center">
        <div className="max-w-3xl">
          <h1 className="text-4xl font-bold text-[#6859FF] whitespace-nowrap">
            Meet Pal—Your New Best Friend For Business
          </h1>
          <br />
          <h1 className="text-2xl font-bold text-[#231F1F]">
            Why shop alone when you can shop with Pal?
          </h1>
          <p className="mt-4 text-lg text-gray-700">
            The app that transforms the way you shop! Whether you're hunting for the latest trends, comparing products,
            or seeking personalized advice, Pal is here to help. Powered by a smart AI avatar, Pal provides instant
            recommendations, detailed product insights, and expert guidance—all tailored just for you.
          </p>
        </div>
        <img src={Image2} alt="Pal Avatar" className="w-64 h-auto rounded-lg" />
      </div>

      <div className="relative mt-20 max-w-sm mx-auto">
        <img src={girl1} alt="Girl 1" className="absolute left-[-50px] top-1/2 transform -translate-y-1/2 w-20 h-auto" />
        <div className="flex bg-white items-center p-4 justify-center">
          <div className="text-center">
            <p className="text-lg text-gray-700 font-medium text-[18px]">Create your Product</p>
            <p className="text-lg text-gray-700">You have no active Product on your account, Create one!</p>
            <div className="text-center">
              <button onClick={handleCreateClick} className="mt-4 bg-[#7D3AFC] text-white py-2 px-4 rounded-lg flex items-center justify-center mx-auto">
                <img src={dashboard} alt="Create Icon" className="w-5 h-5 mr-2" />
                Create
              </button>
            </div>
          </div>
        </div>
        <img src={girl2} alt="Girl 2" className="absolute right-[-50px] top-1/2 transform -translate-y-1/2 w-20 h-auto" />
      </div>
    </div>
  );
};

export default MainContent;
