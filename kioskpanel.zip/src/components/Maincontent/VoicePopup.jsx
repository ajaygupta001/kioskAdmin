import React, { useState, useEffect, useRef } from "react";
import WaveSurfer from "wavesurfer.js";
import VoicePopup from "./VoicePopup";
import Avtar from "@assets/avtar.png";
import Cancel from "@assets/cancel.png";
import { FaPlay, FaPause } from "react-icons/fa";

const PalSelection = ({ onClose, activePal }) => {
  const [selectedPal, setSelectedPal] = useState(activePal || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState(null);
  const [playingVoice, setPlayingVoice] = useState(null);
  const [isVoicePopupOpen, setIsVoicePopupOpen] = useState(false);
  const waveSurferRef = useRef(null);

  const pals = [
    { img: Avtar, value: "animeGirlBlue" },
    // Add other pals here...
  ];

  useEffect(() => {
    const savedPal = localStorage.getItem("selectedPal");
    if (savedPal) {
      setSelectedPal(savedPal);
    } else {
      setSelectedPal(activePal);
    }
  }, [activePal]);

  const handlePalSelect = (value) => {
    setSelectedPal(value);
    localStorage.setItem("selectedPal", value);
  };

  useEffect(() => {
    const fetchVoice = async () => {
      try {
        setLoading(true);
        const response = await fetch(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/get-voices`
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        setVoices(result);
      } catch (error) {
        console.error("Failed to fetch voices:", error);
        setError("Failed to fetch voices.");
      } finally {
        setLoading(false);
      }
    };

    fetchVoice();
  }, []);

  const togglePlayPause = async (voiceKey, event) => {
    event.stopPropagation();

    setSelectedVoice(voiceKey);

    if (playingVoice === voiceKey) {
      waveSurferRef.current.pause();
      setPlayingVoice(null);
    } else {
      try {
        if (waveSurferRef.current) {
          waveSurferRef.current.destroy();
        }

        const res = await fetch(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/files?url=videoRetalking/static/audios/${voices[voiceKey]}`
        );

        if (!res.ok) {
          throw new Error("Failed to fetch audio file.");
        }

        const { base64File } = await res.json();
        const audioUrl = `data:audio/wav;base64,${base64File}`;

        const container = document.getElementById(`waveform-${voiceKey}`);
        waveSurferRef.current = WaveSurfer.create({
          container: container,
          waveColor: "#ddd",
          progressColor: "#6200ea",
          cursorColor: "#ff5500",
          height: 40,
          responsive: true,
          normalize: true,
        });

        waveSurferRef.current.load(audioUrl);
        waveSurferRef.current.on("ready", () => {
          waveSurferRef.current.play();
          setPlayingVoice(voiceKey);
        });

        waveSurferRef.current.on("finish", () => {
          setPlayingVoice(null);
        });
      } catch (error) {
        console.error("Error fetching or playing audio:", error);
        setError("Failed to play audio.");
      }
    }
  };

  const handleSubmit = async () => {
    if (!selectedPal || !selectedVoice) {
      alert("Please select both Avatar and Voice!");
      return;
    }

    const userId = localStorage.getItem("userid");
    const token = localStorage.getItem("authToken");

    if (!token) {
      setError("Authentication token not found. Please log in again.");
      return;
    }

    setLoading(true);
    setError(null);
    setSuccessMessage("");

    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/update-avatar`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            avatarName: selectedPal,
            voiceKey: selectedVoice,
            userId: userId,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(
          `Failed to update avatar. Server returned ${response.status}`
        );
      }

      const data = await response.json();
      setSuccessMessage("Avatar updated successfully!");
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (error) {
      console.error(error);
      setError("Failed to update avatar.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto bg-white rounded-xl shadow-md relative">
      {error && <p className="text-red-500">{error}</p>}
      {successMessage && (
        <p className="text-green-500 font-bold">{successMessage}</p>
      )}

      <button
        className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
        onClick={onClose}
      >
        <img src={Cancel} alt="Close" className="w-4 h-4" />
      </button>

      <h2 className="text-lg font-medium">Select Your Pal & Voice</h2>

      <div className="grid grid-cols-4 gap-4 mt-4">
        {pals.map((pal, index) => (
          <div key={index} className="relative">
            <input
              type="radio"
              name="pal"
              value={pal.value}
              checked={selectedPal === pal.value}
              onChange={() => handlePalSelect(pal.value)}
              className="absolute top-1 right-1"
            />
            <img
              src={pal.img}
              alt={`Pal Avatar ${index + 1}`}
              className="rounded-full w-16 h-16"
            />
          </div>
        ))}
      </div>

      <button
        className="mt-4 bg-purple-600 text-white py-2 px-4 rounded"
        onClick={() => setIsVoicePopupOpen(true)}
      >
        Select Voice
      </button>

      {isVoicePopupOpen && (
        <VoicePopup
          voices={voices}
          selectedVoice={selectedVoice}
          onSelectVoice={setSelectedVoice}
          onClose={() => setIsVoicePopupOpen(false)}
          playingVoice={playingVoice}
          togglePlayPause={togglePlayPause}
        />
      )}

      <div className="flex justify-end mt-4">
        <button
          className="bg-green-500 text-white py-2 px-4 rounded"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? "Updating..." : "Submit"}
        </button>
      </div>
    </div>
  );
};

export default PalSelection;
