import React, { useState } from "react";
import Vector from "@assets/Vector.png";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Cancel from "@assets/cancel.png";
import Confirmationpopup from "../Maincontent/Confirmationpopup";
import { ScaleLoader } from "react-spinners";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const MainContent = (props) => {
  const isEditMode = !!props.workspace?.workspace;
  const [data, setData] = useState(props.workspace?.workspace || {});
  const [loadingProgression, setLoadingProgression] = useState(0);
  const [isPdfFile, setIsPdfFile] = useState("");

  const loadingPercentage = Math.round(loadingProgression * 100);

  console.log(data);

  const [formData, setFormData] = useState({
    workspaceName: isEditMode ? data.product_name || "" : "",
    productInfo: isEditMode ? data.product_info || "" : "",
    productUrl: isEditMode ? data.product_Image || "" : "",
    productImage: isEditMode ? data.product_image || "" : "",
    pdfFile: null,
  });

  const [successMessage, setSuccessMessage] = useState("");

  const [pdfName, setPdfName] = useState(data.pdf_title || "Upload PDF");
  const [pdfUrl, setPdfUrl] = useState(null);
  const [imageUrl, setImageUrl] = useState(null);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [errors, setErrors] = useState({});
  const [generalError, setGeneralError] = useState("");
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
    setFormData((prev) => {
      if (name === "productUrl") {
        setIsPdfFile(false); // Set as not a PDF file
        return { ...prev, [name]: value, pdfFile: null };
      }
      return { ...prev, [name]: value };
    });
    if (name === "productUrl") setGeneralError("");
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];

    if (file) {
      if (file.size > 100 * 1024) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          productImage: "The image size must be less than 100KB.",
        }));
        return;
      }

      const img = new Image();
      img.onload = () => {
        if (img.width > 512 || img.height > 256) {
          setErrors((prevErrors) => ({
            ...prevErrors,
            productImage: "The image dimensions must be 512x256.",
          }));
          return;
        }

        setErrors((prevErrors) => ({ ...prevErrors, productImage: "" }));
        const imageUrl = URL.createObjectURL(file);
        setImageUrl(imageUrl);
        setFormData((prev) => ({ ...prev, productImage: file }));
      };

      img.src = URL.createObjectURL(file);
    } else {
      setImageUrl(null);
      setFormData((prev) => ({ ...prev, productImage: null }));
      setErrors((prevErrors) => ({ ...prevErrors, productImage: "" }));
    }
  };

  const handlePdfChange = (event) => {
    const file = event.target.files[0];

    if (file) {
      if (file.type === "application/pdf") {
        setPdfUrl(URL.createObjectURL(file));
        setPdfName(file.name);
        setFormData((prev) => ({
          ...prev,
          pdfFile: file,
          productUrl: "",
        }));
        setGeneralError("");
      } else {
        toast.error("Please upload a valid PDF file.");
      }
    }
  };


 
   

  

  const handleCancelPdf = () => {
    setPdfName("Upload PDF");
    setPdfUrl(null);
    setFormData((prev) => ({ ...prev, pdfFile: null }));
  };

  const handleCancelImage = () => {
    setImageUrl(null);
    setFormData({ ...formData, productImage: null });
  };

  const validateForm = () => {
    const validationErrors = {};
    let hasGeneralError = false;
  
    // Basic field validation
    if (!formData.workspaceName.trim()) {
      validationErrors.workspaceName = "This field is required";
    }
  
    if (!isEditMode && !formData.productImage && !data.product_image) {
      validationErrors.productImage = "This field is required";
    }
  
    // URL validation
    if (formData.productUrl && !isValidUrl(formData.productUrl)) {
      validationErrors.productUrl = "Please enter a valid URL";
    }
  
    // PDF/URL requirement validation
    if (!formData.productUrl && !pdfUrl && (!data || (!data.pdf_title && !data.productUrl))) {
      validationErrors.productUrl = 'Either Product URL or PDF must be provided';
      validationErrors.productPdf = 'Either Product URL or PDF must be provided';
    }
  
    // Mutual exclusivity validation
    if (!isEditMode && formData.productUrl && formData.pdfFile) {
      validationErrors.productUrl = 'Please provide either a Product URL or a PDF, but not both';
      validationErrors.productPdf = 'Please provide either a Product URL or a PDF, but not both';
      hasGeneralError = true;
    }
  
    return { validationErrors, hasGeneralError };
  };

  const token = localStorage.getItem("authToken");
  console.log("Auth Token:", token);

  const isValidUrl = (url) => {
    const pattern = /^(https?:\/\/)?([a-z0-9-]+\.)+[a-z0-9]{2,7}(\/[^\s]*)?$/;
    return pattern.test(url);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Submit clicked - Edit Mode:", isEditMode);
  
    const { validationErrors, hasGeneralError } = validateForm();
    setErrors(validationErrors);
    setGeneralError(hasGeneralError ? "Please provide either a Product URL or a PDF, but not both" : "");
  
    console.log("Validation Errors:", validationErrors);
    console.log("Has General Error:", hasGeneralError);
  
    if (Object.keys(validationErrors).length === 0 && !hasGeneralError) {
      console.log("Opening popup...");
      setIsPopupOpen(true);
    }
  };
  const handleConfirmPopup = async () => {
    setIsLoading(true);

    try {
      const backendUrl = import.meta.env.VITE_BACKEND_URL;
      const token = localStorage.getItem("authToken");

      if (!token) {
        throw new Error("Authentication token not found. Please log in.");
      }

      const workspaceSlug = isEditMode
        ? props.workspace?.workspace?.workspace_slug
        : null;

      if (isEditMode && !workspaceSlug) {
        throw new Error("Workspace slug not found for editing");
      }

      const endpoint = isEditMode
        ? `${backendUrl}/api/v1/workspace/${workspaceSlug}`
        : `${backendUrl}/api/v1/workspace/create-workspace`;

      const formDataToSend = new FormData();

      if (isEditMode) {
        formDataToSend.append("productName", formData.workspaceName);
        if (formData.productImage) {
          formDataToSend.append("productImage", formData.productImage);
        }
      } else {
        formDataToSend.append("workspaceName", formData.workspaceName);
        formDataToSend.append("productInfo", formData.productInfo);
        if (formData.productUrl) {
          formDataToSend.append("productUrl", formData.productUrl);
        }
        if (formData.pdfFile) {
          formDataToSend.append("pdfFile", formData.pdfFile);
        }
        if (formData.productImage) {
          formDataToSend.append("productImage", formData.productImage);
        }
      }

      const response = await axios[isEditMode ? "patch" : "post"](
        endpoint,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        // First close the popup
        setIsPopupOpen(false);

        // Show success message and wait for it to be displayed
        const successMessage = isEditMode
          ? "Workspace updated successfully!"
          : "Workspace created successfully!";

        toast.success(successMessage, {
          position: "top-right",
          autoClose: 3000,
          onClose: () => {
            // Navigate after the toast is closed
            navigate("/dashboard");
          },
        });
      }
    } catch (error) {
      console.error("Error:", error);
      const errorMessage =
        error.message === "Workspace slug not found for editing"
          ? "Workspace information is missing. Please try again."
          : isEditMode
          ? "Failed to update workspace"
          : "Failed to create workspace";

      toast.error(errorMessage, {
        position: "top-right",
        autoClose: 3000,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClosePopup = () => {
    props.setIsPopupOpen(false);
    setIsPopupOpen(false);
    setGeneralError("");
    console.log("kjkjkjk");
  };
  return (
    <div className="flex justify-center bg-transparent">
      <div className="relative bg-[#F2F2F2] shadow-lg rounded-[10px] max-w-md h-auto p-4">
        {isLoading && (
          <div className="fixed inset-0 z-[100] flex flex-col justify-center items-center bg-gray-500 bg-opacity-50">
            <ScaleLoader size={50} color="#7D3AFC" />
            <p className="mt-2 text-white text-sm">
              {isEditMode
                ? "Product Updating, Please wait"
                : "Product Creating, Please wait"}{" "}
              ({loadingPercentage})
            </p>
          </div>
        )}

        <button
          className="absolute top-4 right-4"
          onClick={handleClosePopup}
          aria-label="Close"
        >
          <img src={Cancel} alt="Close" className="w-4 h-4" />
        </button>

        {successMessage && (
          <div className="bg-green-100 text-green-800 p-3 rounded-md mb-2">
            {successMessage}
          </div>
        )}

        <h2 className="text-lg font-poppins font-medium text-[#2B3B2B] mt-4">
          Add Your Products
        </h2>

        <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-2">
          <div>
            <label className="block text-sm font-medium text-[#58565A] font-poppins mt-4">
              Product Name
            </label>
            <input
              type="text"
              name="workspaceName"
              value={formData.workspaceName}
              onChange={handleChange}
              className="mt-1 p-2 w-full rounded-[10px] border-[1px]"
              disabled={false}
            />
            {errors.workspaceName && (
              <p className="text-red-500 text-xs mt-1">
                {errors.workspaceName}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-[#58565A] font-poppins mt-4">
              Product URL
            </label>
            <input
              type="text"
              name="productUrl"
              value={formData.productUrl}
              onChange={handleChange}
              disabled={isEditMode}
              className={`mt-1 p-2 w-full rounded-[10px] border-[1px] ${
                isEditMode ? "bg-gray-100 cursor-not-allowed" : ""
              }`}
            />

{errors.productUrl && (
              <p className="text-red-500 text-xs mt-1">{errors.productUrl}</p>
            )}
            <div className="flex items-center my-2">
              <div className="flex-grow h-px bg-gray-300"></div>
              <span className="mx-2 text-gray-400">OR</span>
              <div className="flex-grow h-px bg-gray-300"></div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#58565A] font-poppins">
              System Prompt (Optional)
            </label>
            <textarea
              name="productInfo"
              value={data ? data.product_info : formData.productInfo}
              onChange={handleChange}
              className={`p-2 w-full h-20 rounded-[10px] border-[1px] ${
                isEditMode ? "bg-gray-100 cursor-not-allowed" : ""
              }`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#58565A] font-poppins">
              Product PDF
            </label>
            <label
              className={`flex items-center justify-center h-20 rounded-[10px] border-[1px] border-gray-300 overflow-hidden ${
                isEditMode
                  ? "bg-gray-100 cursor-not-allowed"
                  : "bg-[#ffffff] cursor-pointer"
              }`}
            >
              <input
                type="file"
                accept=".pdf"
                className="hidden"
                onChange={handlePdfChange}
                disabled={isEditMode}
              />


              {pdfUrl || data.pdf_title ? (
                <iframe
                  src={pdfUrl || data.pdf_title}
                  className="w-full h-full object-cover"
                  title="PDF Preview"
                  frameBorder="0"
                />
              ) : (
                <div className="flex flex-col items-center">
                  <img src={Vector} alt="Upload" className="w-5 h-5 mr-1" />
                  <span className="text-[#989898] font-poppins text-xs">
                    Upload PDF
                  </span>
                </div>
              )}
            </label>

            {pdfUrl && (
              <button
                type="button"
                onClick={handleCancelPdf}
                className="mt-2 text-sm text-red-500 underline"
              >
                Remove PDF
              </button>
            )}
          </div>

          <div className="col-span-2 flex justify-between items-center mb-4">
            <div className="w-2/4">
              <label className="block text-sm font-medium text-[#58565A] font-poppins text-[16px] leading-[24px]">
                Product Image / Logo
              </label>
              <label className="mt-2 flex items-center justify-center h-24 bg-[#ffffff] cursor-pointer rounded-[10px] border-[1px] border-gray-300 overflow-hidden">
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageChange}
                  disabled={false}
                />
                <div className="flex flex-col items-center justify-center relative">
                  {imageUrl || data.product_image ? (
                    <>
                      <img
                        src={imageUrl || data.product_image}
                        alt="Uploaded"
                        className="w-full h-full object-cover rounded-[10px]"
                      />
                      <button
                        type="button"
                        onClick={handleCancelImage}
                        className="absolute top-2 right-2 text-black font-bold text-lg w-8 h-8 flex items-center justify-center bg-gray-200 rounded-full"
                        aria-label="Cancel Image"
                      >
                        &times;
                      </button>
                    </>
                  ) : (
                    <>
                      <img
                        src={Vector}
                        alt="Upload Icon"
                        className="w-5 h-5 mb-2"
                      />
                      <p className="text-[#989898] font-poppins text-[14px]">
                        Upload here
                      </p>
                    </>
                  )}
                </div>
              </label>

              {errors.productImage && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.productImage}
                </p>
              )}
            </div>

            <div className="w-1/4">
              <button
                type="submit"
                className={`w-full mt-4 h-10 bg-[#7D3AFC] text-white rounded-md text-sm`}
              >
                {isEditMode ? "Edit" : "Create"}
              </button>
            </div>
          </div>
        </form>

        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
        />
      </div>
      {isPopupOpen && (
        <Confirmationpopup
          type={isEditMode ? "edit" : "create"}
          onClose={() => setIsPopupOpen(false)}
          onConfirm={handleConfirmPopup}
        >
          {isLoading ? (
            <div className="flex flex-col items-center justify-center">
              <div
                className="border-4 border-solid border-red-200 rounded-full w-8 h-8 animate-spin"
                style={{ borderLeftColor: "#4caf50" }}
              ></div>
              <p className="mt-2 text-sm text-gray-600">
                {isEditMode ? "Updating workspace..." : "Creating workspace..."}
              </p>
            </div>
          ) : (
            <div className="text-center">
              <p>
                Are you sure you want to {isEditMode ? "update" : "create"} this
                workspace?
              </p>
            </div>
          )}
        </Confirmationpopup>
      )}
    </div>
  );
};

export default MainContent;
