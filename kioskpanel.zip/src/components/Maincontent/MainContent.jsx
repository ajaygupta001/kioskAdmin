import React, { useEffect, useState } from "react";
import Image2 from "@assets/image.png.png";
import dashboard from "@assets/dashboard.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";
import CreateDashboard from "../Maincontent/CreateDashboard";
import Navbar from "../Login/Navbar";

const MainContent = ({ workspaceActive }) => {
  const navigate = useNavigate();
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const isAuthenticated = () => {
    const token = localStorage.getItem("authToken");
    return !!token;
  };

  useEffect(() => {
    if (!isAuthenticated()) {
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    if (workspaceActive) {
      console.log("Workspace is active");
    }
  }, [workspaceActive]);

  const togglePopup = () => {
    setIsPopupOpen(!isPopupOpen);
  };

  return (
    <div className="bg-purple-50 min-h-screen p-4">
    <div className="ml-[-0.9rem] mt-[-1rem]">
    <Navbar />
    </div>
  
    {/* Main Content */}
    <div className="flex flex-col lg:flex-row justify-between items-center bg-[#E7E5FE] p-6 lg:p-8 m-4 lg:m-8 rounded-lg shadow-md">
      <div className="w-full lg:w-1/2 text-center lg:text-left mb-6 lg:mb-0">
        <h1
          className="text-2xl md:text-3xl lg:text-4xl font-medium text-[#6859FF] font-['Roboto_Serif'] mb-4 whitespace-nowrap overflow-hidden"
        >
          Meet Pal—Your Representative For Business
        </h1>
        <h2 className="text-lg md:text-xl font-semibold text-[#231F1F] mb-4">
          Why shop alone when you can shop with Pal?
        </h2>
        <p className="text-sm md:text-base lg:text-lg text-[#959595] font-['Poppins'] leading-relaxed">
          The app that transforms the way you shop! Whether you're hunting for the latest trends, comparing products, or seeking personalized advice, Pal is here to help. Powered by a smart AI avatar, Pal provides instant recommendations, detailed product insights, and expert guidance—all tailored just for you.
        </p>
      </div>
      <img
        src={Image2}
        alt="Pal Avatar"
        className="w-full max-w-md lg:max-w-xs h-auto rounded-lg"
      />
    </div>
  
    {/* Create Product Section */}
    <div className="relative mt-10 w-full max-w-lg mx-auto">
      <div className="flex flex-col items-center bg-white p-6 rounded-xl shadow-sm">
        <p className="text-lg text-[#48464C] font-medium mb-2">Create your Product</p>
        <p className="text-sm md:text-base text-[#6D6D6D] font-normal font-['Poppins'] text-center">
          You have no active Product on your account, Create one!
        </p>
        <button
          onClick={togglePopup}
          className="mt-4 bg-[#7D3AFC] text-white h-12 w-40 lg:h-14 lg:w-64 rounded-lg flex items-center justify-center"
        >
          <img src={dashboard} alt="Create Icon" className="w-5 h-5 mr-2" />
          Create
        </button>
      </div>
    </div>
  
    {/* Popup */}
    {isPopupOpen && (
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
        <div>
          <CreateDashboard setIsPopupOpen={setIsPopupOpen} isPopupOpen={isPopupOpen} />
        </div>
      </div>
    )}
  </div>
  
  );
};

export default MainContent;
