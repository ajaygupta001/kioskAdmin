import React, { useState, useEffect } from "react";
import Cancel from "@assets/cancel.png";
import Saloon from "@assets/saloon.png";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"; // Import styles

const WorkspaceSelection = ({ onClose, workspaces }) => {
  const [selectedWorkspace, setSelectedWorkspace] = useState(null);
  const [toas,setToast]=useState(false)
  const [token, setToken] = useState(
    () => localStorage.getItem("authToken") || ""
  );
  const [activeWorkspace, setActiveWorkspace] = useState(null);

  useEffect(() => {
    const savedToken = localStorage.getItem("authToken");
    if (savedToken) setToken(savedToken);

    const fetchActiveWorkspace = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/active`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setActiveWorkspace(response.data.activeWorkspace);
      } catch (error) {
        console.error("Error fetching active workspace:", error);
      }
    };

    fetchActiveWorkspace();
  }, [token]);

  const handleSelection = (workspaceId) => {
    console.log("Workspace selected:", workspaceId);
    setSelectedWorkspace(workspaceId);
  };

  const handleSwitch = async () => {
    if (!selectedWorkspace) {
      console.error("Workspace ID is required. Please select a workspace.");
      alert("Please select a workspace before switching.");
      return;
    }
  
    if (selectedWorkspace === activeWorkspace) {
      alert(
        "This is your active workspace. You cannot switch to or delete this workspace."
      );
      return;
    }
  
    console.log("Selected Workspace ID (before API call):", selectedWorkspace);
  
    try {
      const response = await axios.post(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/set-active`,
        { workspace_id: selectedWorkspace },
        { headers: { Authorization: `Bearer ${token}` } }
      );
  
     
      toast.success("Product switched successfully!");
      
      
      setTimeout(() => {
        onClose(); 
        window.location.reload(); 
      }, 1000); 
      
    } catch (error) {
      console.error(
        "Error switching workspace:",
        error.response?.data || error.message
      );
      toast.error("Error switching workspace. Please try again.");
    }
  };
  

  return (
    <div className="p-6 w-[600px] mx-auto h-[500px] bg-white rounded-xl shadow-md space-y-4 relative">
      <ToastContainer /> {/* This will render the toast notifications */}
      <button
        className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
        onClick={onClose}
      >
        <img src={Cancel} alt="Close" className="w-6 h-6" />
      </button>
      <h2 className="text-lg font-semibold text-center">
        Switch your Products
      </h2>
      <div className="mt-4 grid grid-cols-2 gap-4 h-[320px] overflow-y-auto">
        {workspaces?.workspaces?.length > 0 ? (
          workspaces.workspaces.map((workspace) => (
            <button
              key={workspace._id}
              onClick={() => handleSelection(workspace.workspace_id)}
              className={`w-full h-[120px] bg-gradient-to-r from-[#6B9176] to-[#A9B774] rounded-lg shadow-lg flex relative p-4 transition-colors ${
                selectedWorkspace === workspace.workspace_id
                  ? "ring-2 ring-purple-500"
                  : "ring-2 ring-green-500"
              }`}
            >
              <img
                src={workspace.product_image || Saloon}
                alt={workspace.product_name || "Product"}
                className="w-16 h-16 rounded-lg mr-4"
              />
              <div className="flex flex-col justify-center">
                <h4 className="text-lg font-medium text-white">
                  {workspace.product_name}
                </h4>
                <p className="text-sm text-white">
                  {workspace.product_info ||
                    "Discover the best in beauty and wellness with our salon app."}
                </p>
              </div>
              <input
                type="radio"
                name="workspace"
                checked={selectedWorkspace === workspace.workspace_id}
                onChange={() => handleSelection(workspace.workspace_id)}
                className="absolute top-2 right-2 w-5 h-5 accent-purple-500"
              />
            </button>
          ))
        ) : (
          <p className="text-center">No workspaces available.</p>
        )}
      </div>
      <button
        className="w-40 mt-4 ml-96 py-2 bg-purple-500 text-white font-semibold rounded-lg shadow-md hover:bg-purple-600"
        onClick={handleSwitch}
      >
        Switch
      </button>
    </div>
  );
};

export default WorkspaceSelection;
