import React, { useState, useEffect, useRef } from "react";
import Avtar from "@assets/avtar.png";
import Avtar1 from "@assets/avtar1.png";
import Avtar3 from "@assets/avtar3.png";
import Avtar5 from "@assets/avtar5.png";
import Avtar6 from "@assets/avtar6.png";
import Avtar7 from "@assets/avtar7.png";
import Avtar8 from "@assets/avtar8.png";
import Avtar9 from "@assets/avtar9.png";
import Avtar10 from "@assets/avtar10.png";
import BritishMan from "@assets/BritishMan.jpeg";
import BritishWoman from "@assets/BritishWoman.jpeg";
import IndianMan from "@assets/IndianMan.jpeg";
import Indianwoman from "@assets/Indianwoman.jpeg";
import AsianMan from "@assets/AsianMan.png";
import AsianWoman from "@assets/AsianWoman.png";
import Cancel from "@assets/cancel.png";

import { FaPlay, FaPause } from "react-icons/fa";
import WaveSurfer from "wavesurfer.js";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Products from "../Settings/Products";

const PalSelection = ({
  activePal,
  onClose,
  setData,
  Data,
  setSelectedPals,
}) => {
  const [selectedPal, setSelectedPal] = useState(activePal || null);
  const [selectedVoice, setSelectedVoice] = useState(null);
  const [activeTab, setActiveTab] = useState("Pal");
  const [voices, setVoices] = useState([]);
  const [playingVoice, setPlayingVoice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const waveSurferRef = useRef(null);
  const [updatedPal, setUpdatedPal] = useState([]);
  const [updatedVoice, setUpdatedVoice] = useState(null);
  const activePalRef = useRef(activePal);
  const [previousPal, setPreviousPal] = useState(null);
  const [previousVoice, setPreviousVoice] = useState(null);

  const [productImage, setProductImage] = useState(null);


  const pals = [
    { img: Avtar, value: "animeGirlBlue" },
    { img: Avtar5, value: "IndianWoman0" },
    { img: Avtar6, value: "boyIndianMan0" },
    { img: Avtar10, value: "boyIndianMan1" },
    { img: Avtar9, value: "boyIndianMan2" },
    { img: Avtar8, value: "IndianWoman1" },
    { img: Avtar7, value: "IndianWoman2" },
    { img: Avtar1, value: "boyanimeBoyBlue" },
    { img: Avtar3, value: "animeGirlDefault" },
    { img: Indianwoman, value: "Indianwoman" },
    { img: IndianMan, value: "IndianMan" },
    { img: BritishWoman, value: "BritishWoman" },
    { img: BritishMan, value: "BritishMan" },
    { img: AsianMan, value: "AsianMan"},
    { img: AsianWoman, value: "AsianWoman"},
    
  ];
  // useEffect(() => {
  //   if (activePal) {
  //     activePalRef.current = activePal;
  //     setSelectedPal(activePal);
  //   }
  // }, [activePal]);

  // console.log(activePal, 'active')

  useEffect(() => {
    const storedPal = localStorage.getItem("previousPal");
    const storedVoice = localStorage.getItem("previousVoice");
    if (storedPal) setPreviousPal(storedPal);
    if (storedVoice) setPreviousVoice(storedVoice);
    if (activePal) {
      activePalRef.current = activePal;
      setSelectedPal(activePal);
    }

    // Set initial selection to either active or previous
    setSelectedPal(activePal || storedPal || null);
    setSelectedVoice(storedVoice || null);
  }, [activePal]);

  // const handlePalSelect = (pal) => {
  //   setSelectedPal(pal);
  //   activePalRef.current = pal; // Update the ref when a new Pal is selected
  // };

  const handlePalSelect = (pal) => {

    console.log("Pal Select Before:", {
      currentPal: selectedPal,
      newPal: pal
    });

    setPreviousPal(selectedPal); // Store current selection as previous
    setSelectedPal(pal);
    activePalRef.current = pal; // Update the ref when a new Pal is selected
    localStorage.setItem("previousPal", pal);


// Find the corresponding image for the selected pal
const selectedPalImage = pal.find(p => p.value === pal)?.img || null;

if (selectedPalImage) {
  setProductImage(selectedPalImage);
}

console.log("Pal Select After:", {
  selectedPal: pal,
  activePalRef: activePalRef.current,
  productImage: selectedPalImage
});

  };


  const handlePalSelectionClose = ({ selectedPal, selectedVoice }) => {
    setCurrentActivePal(selectedPal);
    // other handling...
  };

  const handleVoiceSelect = (voice) => {
    setPreviousVoice(selectedVoice); // Store current selection as previous
    setSelectedVoice(voice);
    localStorage.setItem("previousVoice", voice);
  };
 

  useEffect(() => {
    const fetchVoices = async () => {
      try {
        const response = await fetch(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/get-voices`
        );
        const data = await response.json();
        setVoices(data);
      } catch (error) {
        console.error("Failed to fetch voices:", error);
        setError("Failed to fetch voices.");
      }
    };

    fetchVoices();
  }, []);


  
  const togglePlayPause = async (voiceKey, event) => {
    event.stopPropagation();

    setSelectedVoice(voiceKey);

    if (playingVoice === voiceKey) {
      waveSurferRef.current.pause();
      setPlayingVoice(null);
    } else {
      try {
        if (waveSurferRef.current) {
          waveSurferRef.current.destroy();
        }

        const res = await fetch(
          `${
            import.meta.env.VITE_BACKEND_URL
          }/api/v1/files?url=videoRetalking/static/audios/${voices[voiceKey]}`
        );

        if (!res.ok) {
          throw new Error("Failed to fetch audio file.");
        }

        const { base64File } = await res.json();
        const audioUrl = `data:audio/wav;base64,${base64File}`;

        const container = document.getElementById(`waveform-${voiceKey}`);
        waveSurferRef.current = WaveSurfer.create({
          container: container,
          waveColor: "#ddd",
          progressColor: "#6200ea",
          cursorColor: "#ff5500",
          height: 40,
          responsive: true,
          normalize: true,
        });

        waveSurferRef.current.load(audioUrl);
        waveSurferRef.current.on("ready", () => {
          waveSurferRef.current.play();
          setPlayingVoice(voiceKey);
        });

        waveSurferRef.current.on("finish", () => {
          setPlayingVoice(null);
        });
      } catch (error) {
        console.error("Error fetching or playing audio:", error);
        setError("Failed to play audio.");
      }
    }
  };


  // const handleSubmit = async () => {
  //   if (!selectedPal || !selectedVoice) {
  //     toast.error("Please select a workspace before switching.");
  //     return;
  //   }

  //   const userId = localStorage.getItem("userid");
  //   const token = localStorage.getItem("authToken");

  //   if (!token) {
  //     setError("Authentication token not found. Please log in again.");
  //     return;
  //   }

  //   setLoading(true);
  //   setError(null);
  //   setSuccessMessage("");

  //   try {
  //     const response = await fetch(
  //       `${import.meta.env.VITE_BACKEND_URL}/api/v1/update-avatar`,
  //       {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //           Authorization: `Bearer ${token}`,
  //         },
  //         body: JSON.stringify({
  //           avatarName: selectedPal,
  //           voiceKey: selectedVoice,
  //           userId: userId,
  //         }),
  //       }
  //     );

  //     if (!response.ok) {
  //       throw new Error(
  //         `Failed to update avatar. Server returned ${response.status}`
  //       );
  //     }

  //     const data = await response.json();
  //     toast.success("Avatar Switch successfully!");

  //    setTimeout(() => {
  //     setUpdatedPal(selectedPal);
  //     setUpdatedVoice(selectedVoice);
  //     setData(data);
  //     setSelectedPals(data.activeAvatar);
  //     onClose({ selectedPal, selectedVoice });

  //    }, 2200);

  //     setTimeout(() => {
  //       onClose({ selectedPal, selectedVoice });
  //     }, 2000);
  //   } catch (error) {
  //     console.error(error);
  //     setError("Failed to update avatar.");
  //   } finally {
  //     setLoading(false);
  //   }
  // };



  const handleSubmit = async () => {
    if (!selectedPal || !selectedVoice) {
      toast.error("Please select both a Pal and a Voice.");
      return;
    }

    const userId = localStorage.getItem("userid");
    const token = localStorage.getItem("authToken");

    if (!token) {
      setError("Authentication token not found. Please log in again.");
      return;
    }

    setLoading(true);
    setError(null);
    setSuccessMessage("");
    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/update-avatar`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            avatarName: selectedPal,
            voiceKey: selectedVoice,
            userId: userId,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(
          `Failed to update avatar. Server returned ${response.status}`
        );
      }

      const data = await response.json();
      toast.success("Avatar and Voice updated successfully!");

      // Update stored selections after successful update
      localStorage.setItem("previousPal", selectedPal);
      localStorage.setItem("previousVoice", selectedVoice);

      setTimeout(() => {
        // setData(data);
        // setSelectedPals(data.activeAvatar);
        // onClose({ selectedPal, selectedVoice });

        setUpdatedPal(selectedPal);
        setUpdatedVoice(selectedVoice);
        setData(prevData => ({
          ...prevData,
          profile_image: pals.find(p => p.value === selectedPal)?.img || null
        }));
        // setData(data);
        setSelectedPals(data.activeAvatar);

        setSelectedPals(selectedPal);
        localStorage.setItem("profile_image", pals.find(p => p.value === selectedPal)?.img || "");
    
    

        onClose({ selectedPal, selectedVoice });
      }, 2000);
    } catch (error) {
      console.error(error);
      setError("Failed to update avatar.");
      toast.error("Failed to update avatar and voice.");
    } finally {
      setLoading(false);
    }
  };

  const handleClosePopup = () => {
    onClose();
  };

  useEffect(() => {
    if (activePal) {
      setSelectedPal(activePal); // Update selected pal if activePal changes

    }
    if (selectedVoice) {
      setSelectedVoice(selectedVoice); // Update selected voice if selectedVoice changes
    
    }
  }, [activePal, selectedVoice]);

  console.log(selectedPal, "select pal");
  console.log(selectedVoice, "select voice");

  // console.log(onclose.selectedPal, 'ejfoiweoyue')

  // useEffect(()=>{
  //   onClose({ selectedPal, selectedVoice })
  // },[])

  console.log("195=====", Data);
  return (
    <div className="p-6 w-full max-w-md mx-auto bg-white rounded-lg shadow-lg relative">
      <ToastContainer />
      <button
        className="absolute top-4 right-4"
        onClick={handleClosePopup}
        aria-label="Close"
      >
        <img src={Cancel} alt="Close" className="w-4 h-4" />
      </button>
      <div className="flex justify-center mb-6">
        <button
          className={`px-6 py-2 text-lg font-medium ${
            activeTab === "Pal"
              ? "text-purple-500 border-b-2 border-purple-500"
              : "text-gray-500"
          }`}
          onClick={() => setActiveTab("Pal")}
        >
          Pal
        </button>
        <button
          className={`px-6 py-2 text-lg font-medium ${
            activeTab === "Voice"
              ? "text-purple-500 border-b-2 border-purple-500"
              : "text-gray-500"
          }`}
          onClick={() => setActiveTab("Voice")}
        >
          Voice
        </button>
      </div>

      {error && <p className="text-red-500">{error}</p>}
      {successMessage && <p className="text-green-500">{successMessage}</p>}

      {activeTab === "Pal" ? (
        <div className="grid grid-cols-5 gap-3">
          {pals.map((pal, index) => (
            <div
              key={index}
              className={`relative flex items-center cursor-pointer ${
                selectedPal === pal.value || activePalRef.current === pal.value
                  ? "border-[3px] border-[#6e28f0] rounded-lg"
                  : "border-2 border-transparent"
              }`}
              onClick={() => handlePalSelect(pal.value)}
            >
              <img
                src={pal.img}
                alt={`Pal Avatar ${index + 1}`}
                className="w-[4.5rem] h-[4.5rem] rounded-lg object-cover"
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-6 max-h-56 overflow-y-auto">
          {voices &&
            Object.keys(voices).map((key, index) => (
              <div
                key={index}
                className={`p-4 border ${
                  selectedVoice === key || playingVoice === key
                    ? "border-[#7D3AFC]"
                    : ""
                }`}
                onClick={() => setSelectedVoice(key)}
              >
                <div className="flex justify-center items-center">
                  {playingVoice === key ? (
                    <>
                      <FaPause
                        className="text-lg cursor-pointer text-[#7D3AFC]"
                        onClick={(e) => togglePlayPause(key, e)}
                      />
                      <span className="ml-2 text-[#7D3AFC]">Pause</span>
                    </>
                  ) : (
                    <>
                      <FaPlay
                        className="text-lg cursor-pointer text-[#7D3AFC]"
                        onClick={(e) => togglePlayPause(key, e)}
                      />
                      <span className="ml-2 text-[#7D3AFC]">Play</span>
                    </>
                  )}
                </div>
                <div
                  id={`waveform-${key}`}
                  className="w-full h-12 bg-gray-100 mt-2"
                ></div>
                <p className="text-center text-sm mt-2 text-[#7D3AFC]">{key}</p>
              </div>
            ))}
        </div>
      )}

      <div className="flex justify-end mt-4">
        <button
          className="bg-[#7D3AFC] text-white py-1 px-7 rounded hover:bg-purple-700"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? "Saving..." : "Done"}
        </button>
      </div>
    </div>
  );
};

export default PalSelection;
