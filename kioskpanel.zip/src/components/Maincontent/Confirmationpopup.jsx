import React from "react";

const ConfirmationPopup = ({ onClose, onConfirm, type = "create" }) => {
  // Determine text based on the type
  const isEdit = type === "edit";
  const title = isEdit ? "Edit Confirmation" : "Confirmation";
  const message = isEdit
    ? "Are you sure you want to edit this project? Your changes will be saved."
    : "Are you sure you want to create this project? Once created, the project details will be finalized. You can always make changes later.";
  const confirmText = isEdit ? "Save Changes" : "Create";

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg p-6 text-center max-w-sm mx-auto">
        <div className="mb-4">
          <div className="w-10 h-10 mx-auto mb-2 bg-purple-200 rounded-full flex items-center justify-center">
            <i className="text-purple-500 text-xl">i</i>
          </div>
          <h2 className="text-lg font-semibold text-purple-500">{title}</h2>
        </div>
        <p className="text-gray-700 mb-6">{message}</p>
        <div className="flex justify-around">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gray-200 text-gray-700 rounded-md"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 bg-purple-500 text-white rounded-md"
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationPopup;
