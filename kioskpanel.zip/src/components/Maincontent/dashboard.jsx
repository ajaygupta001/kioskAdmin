import React, { useState, useEffect } from "react";
import MainContent from "./MainContent";
import Products from "../Settings/Products";

const Dashboard = () => {
  const [showMainContent, setShowMainContent] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkWorkspaceStatus = async () => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        console.error("No token provided");
        return;
      }

      try {
        const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/workspaceStatus`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch workspace status");
        }

        const data = await response.json();
        console.log("API Response:", data);

        const workspaceActive = data.WorkspaceCreated;
        setShowMainContent(workspaceActive);
      } catch (error) {
        console.error("Error fetching workspace status:", error);
      } finally {
        setLoading(false);
      }
    };

    checkWorkspaceStatus();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="dashboard">
      <div className="content">
        {showMainContent ? (
          <Products />
        ) : (
          <MainContent workspaceActive={showMainContent} />
        )}
      </div>
    </div>
  );
};

export default Dashboard;
