import React, { useState } from "react";
import showIcon from "@assets/showIcon.jpg";
import eyeicon from "@assets/eyeicon.png";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ChangePasswordModal = ({ isOpen, onClose }) => {
  const [oldPassword, setoldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showoldPassword, setShowoldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  if (!isOpen) return null;

  const handleChangePassword = async () => {
    if (!oldPassword || !newPassword || !confirmPassword) {
      toast.error("All fields are required", { position: "top-right" });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("New passwords do not match", { position: "top-right" });
      return;
    }

    setLoading(true);
    setError("");

    const token = localStorage.getItem("authToken");

    if (!token) {
      toast.error("Authentication token missing. Please log in again.", {
        position: "top-right",
      });
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/confirmReset-password`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            oldPassword,
            newPassword,
          }),
        }
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Something went wrong");
      }

      toast.success("Password changed successfully!", {
        position: "top-right",
      });

      setTimeout(() => {
        onClose();
      }, 3000);
    } catch (err) {
      toast.error(err.message, { position: "top-right" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <ToastContainer />
      <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
        <div className="bg-white rounded-lg w-[30rem] p-6 relative">
          {/* Header */}
          <div className="flex justify-between items-center border-b pb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              Change Password
            </h2>
            <button
              className="text-gray-600 hover:text-gray-800 text-4xl"
              onClick={onClose}
            >
              &times;
            </button>
          </div>

          {/* Form */}
          <div className="mt-4 space-y-4">
            {/* Current Password */}
            {/* Current Password */}
            <div className="relative">
              <label
                htmlFor="current-password"
                className="block text-sm font-medium text-gray-600"
              >
                Enter Current Password
              </label>
              <input
                type={showoldPassword ? "text" : "password"}
                id="current-password"
                value={oldPassword}
                onChange={(e) => setoldPassword(e.target.value)}
                className="w-full mt-1 px-3 py-2 border rounded-lg focus:ring-purple-500 focus:border-purple-500 pr-10"
                placeholder="**********"
              />
              <img
                src={showoldPassword ? showIcon : eyeicon}
                alt="Toggle Visibility"
                className="absolute right-3 top-9 w-5 h-5 cursor-pointer"
                onClick={() => setShowoldPassword(!showoldPassword)}
              />
            </div>

            {/* New Password */}
            <div className="relative">
              <label
                htmlFor="new-password"
                className="block text-sm font-medium text-gray-600"
              >
                New Password
              </label>
              <input
                type={showNewPassword ? "text" : "password"}
                id="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full mt-1 px-3 py-2 border rounded-lg focus:ring-purple-500 focus:border-purple-500 pr-10"
                placeholder="**********"
              />
              <img
                src={showNewPassword ? showIcon : eyeicon}
                alt="Toggle Visibility"
                className="absolute right-3 top-9 w-5 h-5 cursor-pointer"
                onClick={() => setShowNewPassword(!showNewPassword)}
              />
            </div>

            {/* Confirm New Password */}
            <div className="relative">
              <label
                htmlFor="confirm-password"
                className="block text-sm font-medium text-gray-600"
              >
                Confirm New Password
              </label>
              <input
                type={showConfirmPassword ? "text" : "password"}
                id="confirm-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full mt-1 px-3 py-2 border rounded-lg focus:ring-purple-500 focus:border-purple-500 pr-10"
                placeholder="**********"
              />
              <img
                src={showConfirmPassword ? showIcon : eyeicon}
                alt="Toggle Visibility"
                className="absolute right-3 top-9 w-5 h-5 cursor-pointer"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              />
              {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
              {success && (
                <p className="text-green-500 text-sm mt-2">{success}</p>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-center mt-6">
            <button
              className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700"
              onClick={handleChangePassword}
              disabled={loading}
            >
              {loading ? "Changing..." : "Change"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChangePasswordModal;
