import React, { useState, useEffect } from "react";
import { FaRegCalendarAlt } from "react-icons/fa";
import Pagination from "../Login/Pagination";
import noDataImage from "@assets/data.png";
import Filter from "@assets/Filter.png";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Tooltip = ({ text }) => {
  const [isTooltipVisible, setIsTooltipVisible] = useState(false);

  const truncateText = (text) => {
    const words = text.split(" ");
    return words.length > 10 ? words.slice(0, 10).join(" ") + "..." : text;
  };


  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setIsTooltipVisible(true)}
      onMouseLeave={() => setIsTooltipVisible(false)}
    >
      <span className="cursor-help border-b border-dotted whitespace-nowrap overflow-hidden text-ellipsis max-w-[200px] inline-block">
        {truncateText(text)}
      </span>
      {isTooltipVisible && (
        <div className="fixed z-50 p-4 bg-[#E7E5FE] w-[30rem] text-[#333333] text-sm rounded shadow-lg -mt-16">
          {text}
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-x-8 border-t-8 border-x-transparent border-t-[#E7E5FE]"></div>
        </div>
      )}
    </div>
  );
};



const CustomTable = () => {
  const [tableData, setTableData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [sortField, setSortField] = useState("date");
  const [sortOrder, setSortOrder] = useState("asc");
  const rowsPerPage = 10;
  const token = localStorage.getItem("authToken");

  const handleDelete = async (workspaceId) => {
  
  
    try {
      const token = localStorage.getItem("authToken"); // Get token correctly
      if (!token) {
        throw new Error("No authentication token found. Please log in.");
      }
  
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/deleteWorkspaceQA/${workspaceId}`, // Use workspaceId
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Delete Error:", errorData);
        throw new Error(`HTTP error! status: ${response.status}`);
      }
  
      // Update tableData to remove the deleted workspace
      setTableData((prevTableData) =>
        prevTableData.filter((workspace) => workspace._id !== workspaceId)
      );
  
      toast.success("Workspace deleted successfully!");
    } catch (error) {
      console.error("Delete request failed:", error);
      toast.error(error.message || "Failed to delete workspace. Please try again.");
    }
  };
  
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/getWorkspaceChat?sortField=${sortField}&sortOrder=${sortOrder}&page=${currentPage}&limit=${rowsPerPage}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        
        if (!response.ok) {
          const errorData = await response.json();
          console.error("Error response:", errorData);
          throw new Error(`HTTP error! status: ${response.status}`);
        }
  
        const result = await response.json();
        setTableData(result.data);
        setTotalPages(result?.pagination?.totalPages || 1);
      } catch (error) {
        console.error("Fetch error:", error);
      }
    };
  
    fetchData();
  }, [currentPage, sortField, sortOrder, token]); // Ensure token is included
  

  const handleSort = (field) => {
    setSortField(field);
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  return (
    <div className="w-[109rem] p-4 md:p-6 ml-[4rem]">
       <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
<div className="overflow-x-auto max-h-[500px] scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-gray-200">
        <table className="w-full min-w-[640px] table-auto">
        <thead>
  <tr className="bg-gray-100 text-gray-600 text-left">
    <th 
      className="py-3 px-4 font-medium cursor-pointer"
      onClick={() => handleSort("workspaceName")}
    >
      Workspace Name
      {sortField === "workspaceName" && (
        <span className="ml-1">{sortOrder === "asc" ? "↑" : "↓"}</span>
      )}
    </th>
    <th 
      className="py-3 px-4 font-medium cursor-pointer"
      onClick={() => handleSort("question")}
    >
      Question
      {sortField === "question" && (
        <span className="ml-1">{sortOrder === "asc" ? "↑" : "↓"}</span>
      )}
    </th>
    <th className="py-3 px-4 font-medium hidden md:table-cell">Answer</th>
    <th 
      className="py-3 px-4 font-medium hidden sm:table-cell cursor-pointer"
      onClick={() => handleSort("date")}
    >
      Date
      {sortField === "date" && (
        <span className="ml-1">{sortOrder === "asc" ? "↑" : "↓"}</span>
      )}
    </th>
    <th 
      className="py-3 px-4 font-medium hidden sm:table-cell"
    >
      Time
    </th> {/* New column for Time */}
    <th className="py-3 px-4 font-medium text-center">
      <div className="flex items-center justify-center">
        Action
        <img
          src={Filter}
          alt="Filter"
          className="ml-3 -translate-x-1 w-4 h-4"
        />
      </div>
    </th>
  </tr>
</thead>

          <tbody>
  {Array.isArray(tableData) && tableData.length > 0 ? (
    tableData.map((row) => (
      <tr key={row?._id || Math.random()} className="border-b hover:bg-[#E7E5FE]">
        <td className="py-4 px-4 text-gray-700">
          <div className="font-medium">{row?.workspaceName}</div>
          <div className="text-sm text-gray-500 md:hidden mt-1">
            <Tooltip text={row?.answer || ''} />
          </div>
        </td>
        <td className="py-4 px-4 text-gray-700">
          <div className="max-w-xs overflow-hidden text-ellipsis">
            <Tooltip text={row?.question || ''} />
          </div>
        </td>
        <td className="py-4 px-4 text-gray-700 hidden md:table-cell">
          <div className="max-w-xs overflow-hidden text-ellipsis">
            <Tooltip text={row?.answer || ''} />
          </div>
        </td>
        <td className="py-4 px-4 text-gray-700 hidden sm:table-cell">
          <div className="flex items-center">
            <FaRegCalendarAlt className="text-purple-500 mr-2" />
            {row?.date ? new Date(row.date).toLocaleDateString() : ''}
          </div>
        </td>
        <td className="py-4 px-4 text-gray-700 hidden sm:table-cell">
  <div className="flex items-center">
    <span>
      {row?.time && !isNaN(new Date(row.time)) 
        ? new Date(row.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
        : row?.time || "No time available"}
    </span>
  </div>
</td>


<td className="py-4 px-4">
  <div className="flex justify-center gap-2">
    <button
      className="p-2 hover:bg-gray-100 rounded-full"
      onClick={() => handleDelete(row?._id)}
    >
      <svg
        className="w-5 h-5 text-red-500"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
        />
      </svg>
    </button>
  </div>
</td>

      </tr>
    ))
  ) : (
    <tr>
      <td colSpan="6" className="text-center py-8">
        <div className="flex flex-col items-center justify-center text-gray-500">
          <img
            src={noDataImage}
            alt="No Data"
            className="w-30 h-24 mb-4"
          />
          <p className="text-sm font-medium">
            You have no products pal on your account
          </p>
          <p className="text-xl mt-1">Create one!</p>
        </div>
      </td>
    </tr>
  )}
</tbody>

          {/* Pagination inside table */}
          <tfoot>
            <tr>
              <td colSpan="6" className="py-4  px-4 text-center bg-gray-100 ">
                <Pagination
                  totalPages={totalPages}
                  currentPage={currentPage}
                  setCurrentPage={setCurrentPage}
                />
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </div>
  
);
};

export default CustomTable;