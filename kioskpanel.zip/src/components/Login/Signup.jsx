import { useState, useEffect } from "react";
import Chatbot from "@assets/Chatbot.gif";
import profile from "@assets/profile.png";
import email from "@assets/email.png";
import eyeicon from "@assets/eyeicon.png";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";
import { Link, useNavigate } from "react-router-dom";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import showIcon from "@assets/showIcon.jpg";
import { ToastContainer, toast } from "react-toastify"; // Import ToastContainer and toast
import "react-toastify/dist/ReactToastify.css"; // Import the necessary CSS for toast
import { parsePhoneNumberFromString } from "libphonenumber-js";
 
 
 
import "react-toastify/dist/ReactToastify.css"; // Import the CSS
 
const Signin = () => {
  const navigate = useNavigate();
  const googleClientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;
 
 
 
 
 
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    contactNumber: "",
  });
 
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState(""); // New state for password error
  const [success, setSuccess] = useState(false);
  const handleCreateClick = () => navigate("/");
 
  const handleSuccess = async (response) => {
    console.log("Google login successful:", response);
    const token = response.credential;
 
    const decodeJWT = (token) => {
      const base64Url = token.split(".")[1];
      const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
 
      return JSON.parse(jsonPayload);
    };
 
    const decoded = decodeJWT(token);
    console.log("Decoded token:", decoded);
 
    const payload = {
      email: decoded.email,
      name: decoded.name,
      token: token,
      loginMode: "google",
    };
 
    console.log("Google User Info:", payload);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/register`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );
 
      const data = await res.json();
 
      if (res.ok) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("userid", data.userid);
        setSuccess(true);
        navigate("/dashboard");
      } else {
        console.error("Google login failed:", data);
      }
    } catch (error) {
      console.error("Error during Google login:", error);
    }
  };
 
  const handleError = (error) => {
    console.error("Google login failed:", error);
  };
 
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
 
    if (name === "contactNumber") {
      // Only allow digits and limit to 10 characters
      const sanitizedValue = value.replace(/\D/g, "").slice(0, 12);
      setFormData({
        ...formData,
        [name]: sanitizedValue,
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
 
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
 
    if (name === "password") {
      setPasswordError("");
    }
  };
 
  const handlePhoneChange = (value) => {
    if (value) {
      // Extract just the national number without country code
      const phoneNumber = parsePhoneNumberFromString(value);
      if (phoneNumber) {
        const nationalNumber = phoneNumber.nationalNumber;
        // Update the form with just the national number
        setFormData({
          ...formData,
          contactNumber: nationalNumber.slice(0, 12),
        });
      }
    } else {
      setFormData({
        ...formData,
        contactNumber: "",
      });
    }
 
    setErrors((prevErrors) => ({
      ...prevErrors,
      contactNumber: "",
    }));
  };
 
  const validatePhone = (phone) => {
    // Remove any non-digit characters
    const digits = phone.replace(/\D/g, "");
    return digits.length === 12;
  };
 
  const validatePassword = (password) => {
    // Password validation logic
    const passwordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,}$/;
    return passwordRegex.test(password);
  };
 
  const validateForm = () => {
    const newErrors = {};
    const { name, email, password, contactNumber } = formData;
 
    if (!name) {
      newErrors.name = "Name is required";
    }
 
    if (!email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Email address is invalid";
    }
 
    if (!validatePassword(password)) {
      setPasswordError(
        "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character."
      );
      newErrors.password = "Password is invalid";
    } else {
      setPasswordError("");
    }
 
    if (!contactNumber) {
      newErrors.contactNumber = "Phone number is required";
    } else if (!validatePhone(contactNumber)) {
      newErrors.contactNumber = "Please enter a valid 10-digit phone number";
    }
 
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    if (!validateForm()) return;
 
    const payload = {
      name: formData.name,
      email: formData.email,
      password: formData.password,
      contactNumber: formData.contactNumber,
      loginMode: "email",
    };
    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/register`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );
 
      const data = await response.json();
 
      if (response.ok) {
        setSuccess(true);
        console.log("User registered successfully:", data);
      } else {
        // Check for email already exists error
        if (data.message && data.message.includes("email already exists")) {
          toast.error(
            "This email is already registered. Please try another one."
          );
        } else {
          console.error("Registration failed:", data);
        }
      }
    } catch (error) {
      console.error("Error during registration:", error);
    }
  };
 
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => {
        navigate("/");
      }, 3000);
 
      return () => clearTimeout(timer);
    }
  }, [success, navigate]);
 
  return (
    <GoogleOAuthProvider clientId={googleClientId}>
      <div className="min-h-screen bg-white-50 flex flex-col lg:flex-row items-center justify-center p-4 sm:p-6 lg:p-8">
        {/* Image Container */}
        <div className="w-full lg:w-2/5 flex justify-center items-center p-4 sm:p-6 lg:p-8">
          <img
            src={Chatbot}
            alt="Chatbot"
            className="h-[40rem] w-[50rem] object-contain ml-[20rem]"
          />
        </div>
 
        {/* Form Container */}
        <div className="w-full lg:w-3/5 flex justify-center items-center">
          <div className="w-full max-w-[450px] p-4 sm:p-6 md:p-8 lg:p-10">
            {success ? (
              <div className="text-center p-6">
                <h2 className="text-2xl sm:text-3xl font-bold text-green-600">
                  Registration Successful!
                </h2>
                <p className="mt-4 text-base sm:text-lg">
                  Thank you for registering. You can now{" "}
                  <Link to="/" className="text-indigo-600 hover:underline">
                    log in
                  </Link>
                  .
                </p>
              </div>
            ) : (
              <>
                <div className="relative p-8 sm:p-12 rounded-lg max-w-xl w-[40rem] bg-[#E7E5FE] shadow-lg">
                  <h1 className="text-2xl sm:text-3xl lg:text-4xl font-['Roboto_Serif'] font-bold text-center text-[#434343] mb-6 sm:mb-8">
                    Create Your Account
                  </h1>
 
                  <form
                    className="space-y-4 sm:space-y-6"
                    onSubmit={handleSubmit}
                  >
                    {/* Name Input */}
                    <div>
                      <label
                        htmlFor="name"
                        className="block text-base sm:text-lg font-medium text-[#8D8D8D] mb-1"
                      >
                        Name
                      </label>
                      <div className="relative">
                        <img
                          src={profile}
                          alt="Profile Icon"
                          className="absolute w-5 h-5 left-3 top-1/2 transform -translate-y-1/2"
                        />
                        <input
                          type="text"
                          name="name"
                          id="name"
                          className="pl-10 w-full h-11 sm:h-12 text-base border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="Enter your full name..."
                          value={formData.name}
                          onChange={handleInputChange}
                        />
                      </div>
                      {errors.name && (
                        <p className="text-red-500 text-sm mt-1">
                          {errors.name}
                        </p>
                      )}
                    </div>
 
                    {/* Email Input */}
                    <div>
                      <label
                        htmlFor="email"
                        className="block text-base sm:text-lg font-medium text-[#8D8D8D] mb-1"
                      >
                        Email
                      </label>
                      <div className="relative">
                        <img
                          src={email}
                          alt="Email Icon"
                          className="absolute w-5 h-5 left-3 top-1/2 transform -translate-y-1/2"
                        />
                        <input
                          type="email"
                          name="email"
                          id="email"
                          className="pl-10 w-full h-11 sm:h-12 text-base border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="Enter your email..."
                          value={formData.email}
                          onChange={handleInputChange}
                        />
                      </div>
                      {errors.email && (
                        <p className="text-red-500 text-sm mt-1">
                          {errors.email}
                        </p>
                      )}
                    </div>
 
                    {/* Phone Number Input */}
                    <div>
                      <label
                        htmlFor="contactNumber"
                        className="block text-base sm:text-lg font-medium text-[#8D8D8D] mb-1 font-['poppins']"
                      >
                        Phone Number
                      </label>
                      <div className="relative">
                        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 z-10">
                          <PhoneInput
                            value={formData.contactNumber}
                            onChange={(value) =>
                              setFormData({ ...formData, contactNumber: value })
                            }
                            international
                            defaultCountry="IN"
                            maxLength={15}
                            className="w-full border-none focus:ring-0"
                          />
                        </div>
                        <input
                          type="tel"
                          name="contactNumber"
                          id="contactNumber"
                          placeholder="Enter your phone number"
                          value={formData.contactNumber}
                          onChange={handleInputChange}
                          className="pl-24 w-full h-11 sm:h-12 text-base border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>
                      {errors.contactNumber && (
                        <p className="text-red-500 text-sm mt-1">
                          {errors.contactNumber}
                        </p>
                      )}
                    </div>
 
                    {/* Password Input */}
                    <div>
                      <label
                        htmlFor="password"
                        className="block text-base sm:text-lg font-medium text-[#8D8D8D] mb-1"
                      >
                        Password
                      </label>
                      <div className="relative">
                        <input
                          type={showPassword ? "text" : "password"}
                          name="password"
                          id="password"
                          className="pl-3 w-full h-11 sm:h-12 text-base border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="Enter your password"
                          value={formData.password}
                          onChange={handleInputChange}
                        />
                        <img
                          src={showPassword ? showIcon : eyeicon}
                          alt={showPassword ? "Hide Password" : "Show Password"}
                          className={`absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer ${
                            showPassword ? "w-7 h-7" : "w-5 h-5"
                          }`}
                          onClick={togglePasswordVisibility}
                        />
                      </div>
                      {passwordError && (
                        <p className="text-red-500 text-sm mt-1">
                          {passwordError}
                        </p>
                      )}
                    </div>
 
                    {/* Submit Button */}
                    <button
                      type="submit"
                      className="w-full h-11 sm:h-12 mt-6 bg-[#7C39FF] text-white text-base sm:text-lg font-bold rounded-md hover:bg-indigo-700 transition-colors"
                    >
                      Sign up
                    </button>
                  </form>
 
                  {/* Divider */}
                  <div className="flex items-center my-6">
                    <div className="flex-grow h-px bg-gray-300"></div>
                    <span className="mx-4 text-gray-400 text-sm sm:text-base">
                      OR
                    </span>
                    <div className="flex-grow h-px bg-gray-300"></div>
                  </div>
 
                  {/* Google Login */}
                  <GoogleLogin
                    onSuccess={handleSuccess}
                    onError={handleError}
                    render={(renderProps) => (
                      <button
                        onClick={renderProps.onClick}
                        disabled={renderProps.disabled}
                        className="w-full h-11 sm:h-12 bg-red-600 text-white text-base sm:text-lg font-medium rounded-md hover:bg-red-700 transition-colors"
                      >
                        Continue with Google
                      </button>
                    )}
                  />
<div className="mt-6 text-center">
            <span className="text-[#7C39FF] text-base">
             You have an account?{" "}
              <button onClick={handleCreateClick} className="font-semibold">
                Login
              </button>
            </span>
          </div>
                </div>
              </>
            )}
          </div>
        </div>
 
        {/* Toast Container */}
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
        />
      </div>
    </GoogleOAuthProvider>
  );
};
 
export default Signin;