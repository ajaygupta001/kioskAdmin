import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import emailIcon from "@assets/email.png";
import eyeicon from "@assets/eyeicon.png";
import Chatbot from "@assets/Chatbot.gif";
import showIcon from "@assets/showIcon.jpg";
const LoginPage = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [emailInput, setEmailInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showError, setShowError] = useState(false);
  const [loginMessage, setLoginMessage] = useState("");
  const navigate = useNavigate();
 
  const googleClientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;
 
 
  const togglePasswordVisibility = () => setShowPassword(!showPassword);
  const handleForgotPasswordClick = () => navigate("/Resetpassword");
  const handleCreateClick = () => navigate("/Signup");
  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePassword = (password) =>
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
      password
    );
 
  const handleLogin = async (e) => {
    e.preventDefault();
 
    setEmailError("");
    setPasswordError("");
 
    if (!emailInput) {
      setEmailError("Email is required.");
      return;
    }
 
    if (!validateEmail(emailInput)) {
      setEmailError("Please enter a valid email address.");
      return;
    }
 
    if (!passwordInput) {
      setPasswordError("Password is required.");
      return;
    }
 
    if (!validatePassword(passwordInput)) {
      setPasswordError("Password does not meet the requirements.");
      return;
    }
 
    if (!validateEmail(emailInput)) {
      setEmailError("Please enter a valid email address.");
      return;
    }
 
    if (!passwordInput) {
      setPasswordError("Password is required.");
      return;
    }
 
    if (!validatePassword(passwordInput)) {
      setPasswordError("Password does not meet the requirements.");
      return;
    }
 
    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/login`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: emailInput, password: passwordInput }),
        }
      );
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("email", data.email);
        console.log(data, "uuuu")
        navigate("/dashboard");
      } else {
        setErrorMessage("Invalid login credentials.");
        setShowError(true);
      }
    } catch (error) {
      setErrorMessage("An error occurred. Please try again.");
      setShowError(true);
    }
  };
 
  const handleGoogleSuccess = async (response) => {
    console.log("Google login successful:", response);
    const token = response.credential;
 
    const decodeJWT = (token) => {
      const base64Url = token.split(".")[1];
      const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
 
      return JSON.parse(jsonPayload);
    };
 
    const decoded = decodeJWT(token);
 
    const payload = {
      email: decoded.email,
      name: decoded.name,
      token: token,
      loginMode: "google",
    };
    try {
      const res = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/register`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );
 
      const data = await res.json();
 
      if (res.ok) {
        localStorage.setItem("authToken", data.token);
        navigate("/dashboard");
      } else {
        console.error("Google login failed:", data);
      }
    } catch (error) {
      console.error("Error during Google login:", error);
    }
  };
 
  const closeErrorMessage = () => {
    setShowError(false);
  };
 
  const handleGoogleError = (error) => {
    console.error("Google login failed:", error);
  };
 
  return (
    <div className="overflow-y">
    <div className="min-h-screen w-full flex flex-col md:flex-row">
      {loginMessage && (
        <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50">
          {loginMessage}
        </div>
      )}
 
      <div className="w-full md:w-1/2 md:flex justify-center items-center">
        <img
          src={Chatbot}
          alt="Chatbot Animation"
            className="h-[40rem] w-[50rem] object-contain ml-[15rem]"
        />
      </div>
 
      <div className="w-full md:w-1/2 flex justify-center items-center px-6">
        {/* Increased max-width and added padding */}
        <div className="relative p-8 sm:p-12 rounded-lg max-w-xl w-full bg-[#E7E5FE] shadow-lg">
          <h1 className="text-4xl md:text-5xl font-bold text-center text-[#434343] mb-8">
            Login
          </h1>
          <form className="space-y-6 mt-8" onSubmit={handleLogin}>
            <div>
              <label
                htmlFor="email"
                className="block text-[18px] md:text-[22px] text-[#8D8D8D]"
              >
                Email address
              </label>
              <div className="relative flex items-center">
                <img
                  src={emailIcon}
                  alt="Email Icon"
                  className="absolute left-3 w-6 h-6"
                />
                <input
                  type="email"
                  id="email"
                  placeholder="Enter your email..."
                  className="block w-full pl-12 px-4 py-4 border rounded-lg text-lg"
                  value={emailInput}
                  onChange={(e) => {
                    setEmailInput(e.target.value);
                    if (emailError) {
                      setEmailError("");
                    }
                  }}
                  required
                />
              </div>
              {emailError && (
                <p className="text-red-500 text-sm">{emailError}</p>
              )}
            </div>
 
            <div>
              <label
                htmlFor="password"
                className="block text-[18px] md:text-[22px] text-[#8D8D8D]"
              >
                Password
              </label>
              <div className="relative flex items-center">
                <input
                  type={showPassword ? "text" : "password"}
                  id="password"
                  placeholder="Enter your Password"
                  className="block w-full px-4 py-4 border rounded-lg text-lg"
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value);
                    if (passwordError) {
                      setPasswordError("");
                    }
                  }}
                  required
                />
                <img
                  src={showPassword ? showIcon : eyeicon}
                  alt={showPassword ? "Hide Password" : "Show Password"}
                  className={`absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer ${
                    showPassword ? "w-8 h-8" : "w-6 h-6"
                  }`}
                  onClick={togglePasswordVisibility}
                />
              </div>
              {passwordError && (
                <p className="text-red-500 text-sm">{passwordError}</p>
              )}
            </div>
            <div className="text-right">
              <button
                type="button"
                onClick={handleForgotPasswordClick}
                className="text-base text-[#7C39FF] hover:underline"
              >
                Forgot Password?
              </button>
            </div>
            <button
              type="submit"
              className="w-full py-4 bg-[#7C39FF] text-white text-lg font-bold rounded-lg hover:bg-indigo-700"
            >
              Login
            </button>
          </form>
          
          {/* Rest of the code remains the same */}
          <div className="flex items-center justify-between mt-6">
            <hr className="w-full border-gray-300" />
            <span className="mx-4 text-gray-500">OR</span>
            <hr className="w-full border-gray-300" />
          </div>
 
          <div className="mt-6">
            <GoogleOAuthProvider clientId={googleClientId}>
              <GoogleLogin
                onSuccess={handleGoogleSuccess}
                onError={handleGoogleError}
                render={(renderProps) => (
                  <button
                    onClick={renderProps.onClick}
                    disabled={renderProps.disabled}
                    className="w-full py-4 bg-red-600 text-white rounded-lg text-lg"
                  >
                    Continue with Google
                  </button>
                )}
              />
            </GoogleOAuthProvider>
          </div>
 
          <div className="mt-6 text-center">
            <span className="text-[#7C39FF] text-base">
              Don't have an account?{" "}
              <button onClick={handleCreateClick} className="font-semibold">
                Signup
              </button>
            </span>
          </div>
        </div>
      </div>
 
      {showError && (
        <div className="absolute top-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50 flex items-center">
          <span>{errorMessage}</span>
          <button
            className="ml-3 text-white font-bold"
            onClick={closeErrorMessage}
          >
            X
          </button>
        </div>
      )}
    </div>
  </div>
  );
};
export default LoginPage;
 