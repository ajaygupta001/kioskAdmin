import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import pallogo from "@assets/pallogo.png";
import profile1 from "@assets/profile1.png";
import Dropdown from "@assets/Dropdown.png";
import ProfileImage from "@assets/ProfileImage.png";
import Option from "@assets/Option.png";
import ChangePassword from "./ChangePassword.jsx"; // Import the ChangePasswordModal component

const Navbar = () => {
  const [userName, setUserName] = useState("");
  const [profileImage, setProfileImage] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // State for modal
  const navigate = useNavigate();

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    const token = localStorage.getItem("authToken");
    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/getEmail`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setUserName(data.userName || "");
        setProfileImage(data.profileImage || "");
      } else {
        console.error("Error fetching user data");
      }
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("token");
    localStorage.removeItem("userid");
    navigate("/");
  };

  const handleNavigateToProfile = () => {
    navigate("/profile");
  };

  const handleOpenChangePassword = () => {
    setIsModalOpen(true); // Open the modal
  };

  const handleCloseModal = () => {
    setIsModalOpen(false); // Close the modal
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".profile-dropdown")) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="bg-white shadow-sm w-screen h-[4.5rem]">
      <div className="flex items-center justify-between px-6 h-full">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <img src={pallogo} alt="Pal Logo" className="h-12 inline-block mt-1" />
        </div>

        {/* User Profile with Dropdown */}
        <div className="relative profile-dropdown mr-[1rem]">
          <div
            className="flex items-center space-x-2 bg-[#F4F3FF] w-38 rounded-xl p-2 cursor-pointer hover:bg-[#ECEAFF] transition-colors"
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          >
            <img
              src={profileImage || ProfileImage}
              alt="Profile"
              className="w-8 h-8 rounded-full object-cover"
            />
            <span className="text-gray-800 font-medium hidden sm:block whitespace-nowrap overflow-hidden text-ellipsis">
              {userName || "User"}
            </span>

            <img
              src={Dropdown}
              alt="dropdown"
              className="w-6 h-6 object-contain"
            />
          </div>

          {/* Dropdown Menu */}
          {isDropdownOpen && (
            <div className="absolute right-0 mt-2 w-[10rem] rounded-lg shadow-lg py-1 z-50 bg-white">
              {/* Logout Button */}
              <button
                onClick={handleLogout}
                className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 flex items-center space-x-2"
              >
                <img
                  src={Option}
                  alt="logout"
                  className="w-6 h-6 object-contain"
                />
                <span>Logout</span>
              </button>

              {/* Profile Button */}
              <button
                onClick={handleNavigateToProfile}
                className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 flex items-center space-x-2"
              >
                <img
                  src={Option}
                  alt="profile"
                  className="w-6 h-6 object-contain"
                />
                <span>Profile</span>
              </button>

              {/* Change Password Button */}
              <button
                onClick={handleOpenChangePassword} // Open the Change Password modal
                className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 flex items-center space-x-2"
              >
                <img
                  src={Option}
                  alt="password"
                  className="w-6 h-6 object-contain"
                />
                <span>Password</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Change Password Modal */}
      {isModalOpen && (
        <ChangePassword isOpen={isModalOpen} onClose={handleCloseModal} />
      )}
    </nav>
  );
};

export default Navbar;
