import React, { useState } from "react";
import { FaAngleLeft, FaAngleRight } from "react-icons/fa";

const Pagination = ({ totalPages = 10, currentPage, setCurrentPage }) => {
  const [inputPage, setInputPage] = useState("");

  const goToPage = (e) => {
    e.preventDefault();
    const page = parseInt(inputPage, 10);
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
    setInputPage("");
  };

  const renderPages = () => {
    const pages = [];
    const maxPageNumbers = 5;

    for (let i = 1; i <= Math.min(maxPageNumbers, totalPages); i++) {
      pages.push(
        <button
          key={i}
          className={`w-8 h-8 flex items-center justify-center rounded-full border 
                      ${
                        currentPage === i
                          ? "bg-[#6859FF] text-white"
                          : "hover:bg-gray-200 text-gray-700"
                      }`}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </button>
      );
    }

    if (totalPages > maxPageNumbers) {
      pages.push(
        <span key="dots" className="mx-2 text-gray-700">
          ...
        </span>
      );

      pages.push(
        <button
          key={totalPages}
          className={`w-8 h-8 flex items-center justify-center rounded-full border 
                      ${
                        currentPage === totalPages
                          ? "bg-[#6859FF] text-white"
                          : "hover:bg-gray-200 text-gray-700"
                      }`}
          onClick={() => setCurrentPage(totalPages)}
        >
          {totalPages}
        </button>
      );
    }

    return pages;
  };

  return (
    <div className="flex items-center ">
      {/* Pagination Controls */}
      <div className="flex items-center space-x-2 ml-[48rem] items-center">
        <button
          className="w-10 h-10 flex items-center justify-center rounded-full border hover:bg-gray-200 text-gray-700"
          onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          disabled={currentPage === 1}
        >
          <FaAngleLeft />
        </button>

        {renderPages()}

        <button
          className="w-10 h-10 flex items-center justify-center rounded-full border hover:bg-gray-200 text-gray-700"
          onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
          disabled={currentPage === totalPages}
        >
          <FaAngleRight />
        </button>
      </div>

      {/* Go to Page Input */}
      <div className="flex space-x-2 ml-[30rem]">
      <button
          className="bg-[#6859FF] text-white px-4 py-2 rounded-lg"
          onClick={goToPage}
        >
          Page
        </button>
        <select
  className="border px-3 py-1 rounded-lg w-20 text-center text-gray-700"
  value={inputPage}
  onChange={(e) => setInputPage(e.target.value)}
>
  {[...Array(totalPages)].map((_, index) => (
    <option key={index + 1} value={index + 1}>
      {index + 1}
    </option>
  ))}
</select>

      
      </div>
    </div>
  );
};

export default Pagination;
