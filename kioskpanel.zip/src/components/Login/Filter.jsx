import React, { useState } from "react";
import Action from "@assets/Action.png";

const FilterInput = () => {
  const [filter, setFilter] = useState(""); // State for input value
  const [items] = useState([]); // Sample list of items
  const filteredItems = items.filter((item) =>
    item.toLowerCase().includes(filter.toLowerCase())
  ); // Filter logic

  return (
    <div className="flex flex-col items-center justify-center p-6 mr-[-8rem]">
      {/* Input Field */}
      <div className="relative w-32 mb-4">
        <input
          type="text"
          placeholder="Type Filter.."
          className="w-full p-2 pr-10  border-gray-300 border rounded-lg rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        {/* Action Image */}
        <img
          src={Action}
          alt="Action"
          className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 cursor-pointer"
        />
      </div>

      {/* Filtered Items */}
    </div>
  );
};

export default FilterInput;
