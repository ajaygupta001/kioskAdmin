import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Chatbot from "@assets/Chatbot.gif";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ResetPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const handleContinue = async (event) => {
    event.preventDefault();

    if (!email.trim()) {
      setError("Please fill this field");
      return;
    }

    setError("");

    try {
      const response = await fetch(
        `${
          import.meta.env.VITE_BACKEND_URL
        }/api/v1/user/check-email-verification`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email }),
        }
      );

      if (response.ok) {
        toast.success("Email verify successfully.");

        setTimeout(() => {
          navigate("/createpassword", { state: { email } });
        }, 2000);
      } else {
        const data = await response.json();
        setError(data.message || "Something went wrong");
      }
    } catch (error) {
      setError("An error occurred. Please try again later.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <div className="w-full md:w-1/2 flex justify-center items-center ">
        <img
          src={Chatbot}
          alt="Chatbot Animation"
         className="h-[40rem] w-[50rem] object-contain ml-[15rem]"
        />
      </div>

      <div className="w-full md:w-1/2 flex justify-center items-center px-6 py-8">
        <div className="max-w-md w-full">
        <div className="relative p-8 sm:p-12 rounded-lg max-w-xl w-[40rem] bg-[#E7E5FE] shadow-lg">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Reset your Password
          </h1>
          <p className="text-sm md:text-base text-gray-500 mb-6">
            Enter the email associated with your account and we will send an
            email with instructions to reset your password.
          </p>
          <form onSubmit={handleContinue}>
            <div className="mb-4">
              <label
                htmlFor="email"
                className="block text-sm md:text-base text-gray-600 mb-2"
              >
                Email address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your mail..."
                className={`w-full px-4 py-3 border ${
                  error ? "border-red-500" : "border-gray-300"
                } rounded-lg focus:outline-none focus:ring-2 ${
                  error ? "focus:ring-red-500" : "focus:ring-indigo-500"
                }`}
              />
              {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition duration-300"
            >
              Continue
            </button>
          </form>
        </div>
        </div>
      </div>

      <ToastContainer />
    </div>
  );
};

export default ResetPassword;
