import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import robot from "@assets/robot.png";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import eyeicon from "@assets/eyeicon.png";
import showIcon from "@assets/showIcon.jpg";

const CreateNewPassword = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const email = location.state?.email;

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

 
  const validatePassword = (password) => {
    const passwordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,}$/;
    return passwordRegex.test(password);
  };

  const handlePasswordChange = (e) => {
    const newPassword = e.target.value;
    setPassword(newPassword);


    if (passwordError) {
      setPasswordError(""); 
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
  
  
    if (!email) {
      toast.error("Invalid email. Please try again.");
      return;
    }
  
    // Password validation check
    if (!validatePassword(password)) {
      setPasswordError(
        "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character."
      );
      return;
    } else {
      setPasswordError(""); 
    }
  
   
    if (password !== confirmPassword) {
      toast.error("Passwords do not match!");
      return;
    }
  

    if (password.length < 8) {
      toast.error("Password must be at least 8 characters long!");
      return;
    }
  
    const resetPasswordURL = `${
      import.meta.env.VITE_BACKEND_URL
    }/api/v1/user/reset-password`;
  
    try {
      const response = await fetch(resetPasswordURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });
  
      if (!response.ok) {
        throw new Error("Password reset failed");
      }
  
      const data = await response.json();
      toast.success(data.message || "Password reset successful!");
      localStorage.setItem("userEmail", email);
      
  
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);
    } catch (error) {
      toast.error(error.message || "Something went wrong. Please try again.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white px-4">
      <div className="flex flex-col md:flex-row items-center space-y-8 md:space-y-0 md:space-x-8 w-full max-w-5xl">
        <div className="flex-shrink-0 flex justify-center md:justify-end w-full md:w-1/2">
          <img
            src={robot}
            alt="Robot"
            className="w-[10rem] h-[12rem] md:w-[15rem] md:h-[17rem] xl:w-[19.875rem] xl:h-[22.1875rem]"
          />
        </div>
        <div className="w-full md:w-1/2 flex justify-center bg-[#E7E5FE]">
          <div className="w-full max-w-sm md:max-w-md">
            <h2 className="text-[1.75rem] md:text-[2rem] xl:text-[2.5rem] font-['Roboto_Serif'] font-bold text-gray-800 mb-4 text-center md:text-left">
              Create New Password
            </h2>

            <p className="text-sm md:text-base text-gray-500 mb-4 text-center md:text-left">
              Your new password must be different from the previous password.
            </p>

            <form onSubmit={handleResetPassword}>
              <div className="mb-6">
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your Password"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 pr-12"
                    value={password}
                    onChange={handlePasswordChange}
                  />
                  <img
                    src={showPassword ? showIcon : eyeicon}
                    alt={showPassword ? "Hide Password" : "Show Password"}
                    className={`absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer ${
                      showPassword ? "w-8 h-8" : "w-5 h-5"
                    }`}
                    onClick={togglePasswordVisibility}
                  />
                </div>
                {passwordError && (
                  <p className="text-sm text-red-500 mt-2">{passwordError}</p>
                )}
                <p className="text-sm text-gray-500 mt-2">
                  Must be at least 8 characters
                </p>
              </div>

              <div className="mb-6">
                <label
                  htmlFor="confirmPassword"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Confirm Password
                </label>
                <div className="relative">
                  <input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="Confirm your Password"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 pr-12"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                  />
                  <img
                    src={showConfirmPassword ? showIcon : eyeicon}
                    alt={
                      showConfirmPassword ? "Hide Password" : "Show Password"
                    }
                    className={`absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer ${
                      showConfirmPassword ? "w-8 h-8" : "w-5 h-5"
                    }`}
                    onClick={toggleConfirmPasswordVisibility}
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Both passwords must match
                </p>
              </div>

              <button
                type="submit"
                className="w-full bg-[#7C39FF] text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition"
              >
                Reset Password
              </button>
            </form>
          </div>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default CreateNewPassword;
