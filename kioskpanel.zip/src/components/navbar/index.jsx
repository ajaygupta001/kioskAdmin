import logo from "../../assets/logo.png";

function Navbar() {
  return (
    <div className="w-full bg-transparent">
      <div className="p-6">
        <img src={logo} />
      </div>
    </div>
  );
}

export default Navbar;
