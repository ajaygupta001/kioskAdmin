import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import editicon from "@assets/editicon.png";
import profile1 from "@assets/profile1.png";
import Navbar from "../Login/Navbar";
import Profileline from "@assets/Profileline.png";
import Interchange from "@assets/Interchange.png";
import Dropdown from "@assets/Dropdown.png";
import countryLanguage from "country-language";

const ProfilePage = () => {
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [originalUserName, setOriginalUserName] = useState("");
  const [isEdited, setIsEdited] = useState(false);
  const [profileImage, setProfileImage] = useState(null);
  const [previewImage, setPreviewImage] = useState("");
  const [language, setLanguage] = useState("");
  const [languages, setLanguages] = useState([]);
  const [gender, setGender] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [isFileInputVisible, setIsFileInputVisible] = useState(false); // New state to handle edit mode

  const handleProfileClick = () => {
    setIsFileInputVisible(true); // Show the file input when profile image is clicked
  };

  const navigate = useNavigate();

  const handleNavigation = () => {
    navigate("/Products"); // Adjust the route path to match your setup
  };
  useEffect(() => {
    countryLanguage.getLanguages((err, languages) => {
      if (err) {
        console.error("Error fetching languages:", err);
        return;
      }
      // Filter out invalid entries and remove duplicates
      const uniqueLanguages = languages
        .filter((lang) => lang.name) // Ensure each language has a name
        .reduce((acc, lang) => {
          if (!acc.some((l) => l.iso639_1 === lang.iso639_1)) {
            acc.push(lang); // Add unique languages
          }
          return acc;
        }, []);
        console.log("Fetched languages:", languages); 
      setLanguages(uniqueLanguages);
    });
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(file);
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const fetchEmailData = async () => {
    const token = localStorage.getItem("authToken");
    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/getEmail`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setUserName(data.userName || "");
        setOriginalUserName(data.userName || "");
        setUserEmail(data.userEmail || "");
        setPreviewImage(data.profileImage || "");
      } else {
        const error = await response.json();
        console.error("Error fetching data:", error);
      }
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const handleSave = async () => {
    const token = localStorage.getItem("authToken");
    const formData = new FormData();
    formData.append("userName", userName);
    formData.append("language", language);
    if (profileImage) {
      formData.append("profileImage", profileImage);
    }

    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/user/updateProfile`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        }
      );

      if (response.ok) {
        const data = await response.json();
        setOriginalUserName(userName);
        setIsEdited(false);
        setIsEditing(false); // Set to false when saving

        if (data.profileImage) {
          setPreviewImage(data.profileImage);
        }

        setProfileImage(null);
        toast.success("Profile updated successfully!");
      } else {
        toast.error("Failed to update profile.");
      }
    } catch (error) {
      console.error("Error making API call:", error);
      toast.error("Error updating profile.");
    }
  };

  useEffect(() => {
    fetchEmailData();
  }, []);

  useEffect(() => {
    setIsEdited(userName !== originalUserName);
  }, [userName, originalUserName]);

  const handleEditClick = () => {
    setIsEditing(true); 
  };

  return (
    <div className="flex flex-col items-center bg-[#F4F3FF] min-h-screen py-10 px-4">
      <div className="mt-[-2.5rem]">
        <Navbar />
      </div>
      <ToastContainer />
      <div className="font-poppins font-medium text-[2.125rem] leading-[3.1875rem] text-center w-[6.75rem] h-[3.1875rem] mr-[77rem] mt-[5rem] absolute">
        Profile
      </div>
      <div>
        <img
          src={Profileline}
          alt="Profile"
          className="mr-[67rem] mt-[4rem] h-[2rem]"
        />
      </div>
      <div
        className="absolute top-[7.5rem] left-[25rem] flex items-center p-4 cursor-pointer"
        onClick={handleNavigation}
      >
        <img
          src={Interchange}
          alt="Profile"
          className="mr-2 h-[1.5rem]" // Adjust the margin for spacing
        />
        <p className="mr-20">Back to dashboard</p>{" "}
        {/* Added margin-left for spacing */}
      </div>

      <div className="bg-white p-8 rounded-lg shadow-md w-[85rem] h-[35rem] max-w-full max-h-full mt-[2rem]">
        {/* Profile Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="relative w-24 h-24">
              <div className="w-24 h-24 rounded-full border-4 border-gray-100">
                <img
                  src={previewImage || profile1}
                  alt="Profile"
                  className="w-full h-full rounded-full object-cover cursor-pointer"
                  onClick={handleProfileClick} // Add onClick handler to toggle file input visibility
                />
              </div>

              {isFileInputVisible && ( // Conditionally render the file input
                <label className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-white p-1 cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </label>
              )}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{userName}</h1>
              <p className="text-gray-600">{userEmail}</p>
            </div>
          </div>
          <button
            onClick={isEditing ? handleSave : handleEditClick}
            className={`px-10 py-3 rounded-md font-medium ${
              isEditing || profileImage
                ? "bg-purple-600 text-white hover:bg-purple-700"
                : "bg-purple-600 text-white hover:bg-purple-700"
            }`}
          >
            {isEditing ? "Save" : "Edit"} {/* Toggle between Edit and Save */}
          </button>
        </div>

        {/* Profile Form Section */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* User Name */}
          <div>
            <label
              htmlFor="userName"
              className="block font-poppins font-[400] text-[18.92px] leading-[31.38px] text-[#000000]"
            >
              First Name
            </label>
            <input
              type="text"
              id="userName"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="block  w-[30rem] h-[3rem] mt-2  px-4 py-4 border rounded-lg text-lg"
              placeholder="Enter your name"
              disabled={!isEditing} // Disable input if not in edit mode
            />
          </div>

          {/* Last Name */}
          <div>
            <label
              htmlFor="lastName"
              className="block font-poppins font-[400] text-[18.92px] leading-[31.38px] text-[#000000]"
            >
              Last Name
            </label>
            <input
              type="text"
              id="lastName"
              value="Verma"
              className="block w-[30rem] h-[3rem] mt-2  px-4 py-4 border rounded-lg text-lg"
              placeholder="Enter your last name"
              disabled // Last Name is static
            />
          </div>

          {/* Language */}
          <div>
            <label
              htmlFor="language"
              className="block font-poppins font-[400] text-[18.92px] leading-[31.38px] text-[#000000]"
            >
              Language
            </label>
            <div className="relative w-[30rem] mt-2">
            <select
  id="language"
  value={language}
  onChange={(e) => setLanguage(e.target.value)}
  className="block w-full h-[3rem] border rounded-lg text-lg appearance-none pr-10 pl-3"
  disabled={!isEditing}
>
  <option value="">Select Language</option>
  {languages.length > 0 ? (
    languages.map((lang, index) => (
      <option key={index} value={lang.name}>
        {lang.name}
      </option>
    ))
  ) : (
    <option value="" disabled>
      No languages available
    </option>
  )}
</select>


              <img
                src={Dropdown}
                alt="Dropdown Icon"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none w-5 h-5"
              />
            </div>
          </div>

          {/* Gender */}
          <div>
            <label
              htmlFor="gender"
              className="block font-poppins font-[400] text-[18.92px] leading-[31.38px] text-[#000000]"
            >
              Gender
            </label>
            <div className="relative w-[30rem]">
              <select
                id="gender"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="block w-full h-[3rem] mt-2 border rounded-lg text-lg appearance-none pr-10 pl-3"
                disabled={!isEditing} // Disable select if not in edit mode
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              <img
                src={Dropdown} // Import your Dropdown.png image
                alt="Dropdown"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none w-5 h-5"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
