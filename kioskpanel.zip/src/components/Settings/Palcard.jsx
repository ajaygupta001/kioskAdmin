import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getAuthToken, isAuthenticated } from "/src/utils/auth";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Sidebar from "../Sidebar/Sidebar";
import Saloon from "@assets/Saloon.png";
import line1 from "@assets/line1.png";
import line2 from "@assets/line2.png";
import voicee from "@assets/voicee.png";
import Image2 from "@assets/image.png.png";
import Avtar from "@assets/avtar.png";
import Avtar1 from "@assets/avtar1.png";
import Avtar3 from "@assets/avtar3.png";
import Avtar5 from "@assets/avtar5.png";
import Avtar6 from "@assets/avtar6.png";
import Avtar7 from "@assets/avtar7.png";
import Avtar8 from "@assets/avtar8.png";
import Avtar9 from "@assets/avtar9.png";
import Avtar10 from "@assets/avtar10.png";
import Pal from "../Maincontent/Pal";
import Workspace from "../Maincontent/Workspace";
import BritishMan from "@assets/BritishMan.jpeg";
import BritishWoman from "@assets/BritishWoman.jpeg";
import IndianMan from "@assets/IndianMan.jpeg";
import Indianwoman from "@assets/Indianwoman.jpeg";
import { toast, ToastContainer } from "react-toastify";
import CustomTable from "../Login/Customtable";
import Pagination from "../Login/Pagination";
import { FaPause, FaPlay } from "react-icons/fa";
import arrow1 from "@assets/arrow1.png";


import Navbar from "../Login/Navbar";
import Voice from "@assets/Voice.png";


const DashboardContent = (data, value)  => {
  const navigate = useNavigate();
  const [workspaces, setWorkspaces] = useState([]);
  const [error, setError] = useState("");
  const [Data, setData] = useState("");
  const [loading, setLoading] = useState(true);
  const [isWorkspacePopupOpen, setWorkspacePopupOpen] = useState(false);
  const [isloading, issetLoading] = useState(false);
  const [voices, setVoices] = useState([]);
  const [playingVoice, setPlayingVoice] = useState(null);
  const waveSurferRef = useRef(null);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [selectedPal, setSelectedPal] = useState(
    localStorage.getItem("selectedPal") || null
  );
  const [selectedVoice, setSelectedVoice] = useState(
    localStorage.getItem("selectedVoice") || null
  );
  const [isPalPopupOpen, setPalPopupOpen] = useState(false);
  const [currentActivePal, setCurrentActivePal] = useState(null);
  

  const pals = {
    animeGirlBlue: Avtar,
    boyanimeBoyBlue: Avtar1,
    animeGirlDefault: Avtar3,
    IndianWoman0: Avtar5,
    boyIndianMan0: Avtar6,
    IndianWoman2: Avtar7,
    IndianWoman1: Avtar8,
    boyIndianMan2: Avtar9,
    boyIndianMan1: Avtar10,
    Indianwoman: Indianwoman,
    IndianMan: IndianMan,
    BritishWoman: BritishWoman,
    BritishMan: BritishMan,
  };
  const togglePlayPause = (key) => {
    if (playingVoice === key) {
      setPlayingVoice(null);
    } else {
      setPlayingVoice(key);
    }
  };
  // debugger;

  const handlePalSelection = (palKey) => {
    // Set the selected pal
    setSelectedPal(palKey);

    // Save the selected pal to localStorage
    localStorage.setItem("selectedPal", palKey);

    // Call closesomeVoicePalPopup and pass the selected pal and voice info
    closePalPopup({ selectedPal: palKey, selectedVoice: "" }); // Assuming you have the selectedVoice logic
    console.log(selectedPal, "SELECTED");

    // After closing the popup, set the current active pal
    // Using a callback or a state change after closing
    setCurrentActivePal(selectedPal); // Set selected pal as current active pal
  };

  const handleVoiceSelection = (voiceKey) => {
    setSelectedVoice(voiceKey);
    localStorage.setItem("selectedVoice", voiceKey); // Save to localStorage
  };

  useEffect(() => {
    const fetchWorkspace = async () => {
      try {
        const token = getAuthToken();
        if (!token) {
          throw new Error("No authentication token found. Please log in.");
        }

        const response = await axios.get(
          `${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/active`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (response.status === 200) {
          issetLoading(true);
          setData(response.data.workspace);
          setSelectedPal(response.data.activeAvatar);
        }

        setWorkspaces(response.data);
        setLoading(false);
      } catch (err) {
        if (err.response?.status === 401) {
          navigate("/login");
        } else {
          console.error("Error fetching workspace data:", err);
          setError(err.response?.data?.message || err.message);
          setLoading(false);
        }
      }
    };

    fetchWorkspace();
  }, [navigate]);

  const openWorkspacePopup = async () => {
    try {
      const token = getAuthToken();
      const response = await axios.get(
        `${import.meta.env.VITE_BACKEND_URL}/api/v1/workspace/get`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.status === 200) {
        setWorkspaces(response.data);
        setWorkspacePopupOpen(true);
      }
    } catch (error) {
      console.error("Error fetching workspace data:", error);
      setError(error.response?.data?.message || error.message);
    }
  };

  useEffect(() => {
    const savedPal = localStorage.getItem("selectedPal");
    if (savedPal) {
      setSelectedPal(savedPal);
    }
  }, []);

  const closeWorkspacePopup = () => setWorkspacePopupOpen(false);

  const openPalPopup = () => setPalPopupOpen(true);
  const closePalPopup = () => setPalPopupOpen(false);

  if (loading) {
    return <div className="flex-1 bg-purple-50 p-8">Loading...</div>;
  }

  if (error) {
    return (
      <div className="bg-purple-50 min-h-screen  ">
        <div className="bg-red-100 text-red-700 p-4 rounded-md">{error}</div>
      </div>
    );
  }
  console.log("179====", selectedPal);
  return (
    <div className="flex">
    <div className="flex-1 bg-purple-50 w-screen overflow-x-auto">
      <div className="container min-w-[1200px]">
         <div className="mt-6 ml-20">
                 <div className="w-[92vw] h-[15rem] rounded-lg bg-[#E7E5FE] p-[3rem] custom-border">
                   <div className="flex flex-col lg:flex-row justify-between gap-8">
                     <div className="flex flex-col sm:flex-row items-center gap-6">
                       <div className="flex flex-col item-start justify-between mt-[-4rem]">
                         {/* Active Product */}
                         <div className="flex flex-col items-center justify-between ml-[-3rem]">
                           <img
                             src={line1}
                             alt="line decoration"
                             className="w-0.5 h-12 mb-15"
                           />
                           <span className="font-medium text-[#333333] -rotate-90 whitespace-nowrap transform mt-14">
                             Active Product
                           </span>
       
                           <img
                             src={line2}
                             alt="line decoration"
                             className="mt-14"
                           />
                         </div>
                       </div>
                       <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-2 border-[#FFFFFF] overflow-hidden flex-shrink-0 ml-2 flex items-center justify-center">
                         <img
                           src={isloading ? Data.product_image : Saloon}
                           alt="Product"
                           className="max-w-full max-h-full object-contain w-[7rem] h-[7rem]"
                         />
                       </div>
       
                       <div className="flex flex-col  items-center sm:items-start ml-[2rem] mt-[2rem]">
                         <h2 className="text-xl text-[#333333] font-medium  font-poppins font-semibold text-[20px] leading-[30px]">
                           {isloading ? Data.product_name : "Salon App"}
                         </h2>
                         <p className="text-sm text-[#333333] mb-6 max-w-xs text-center sm:text-left">
                           {isloading
                           
                             ? Data.product_info
                             : "Discover the best in beauty and wellness with our easy-to-use salon app."}
                                                   {console.log(Data.product_info ,"INFo")}
       
                         </p>
                         <button
         onClick={openWorkspacePopup}
         className="px-6 py-2 border-2 text-customPurple/80 border-customPurple/80 ml-[20rem] mt-[-1rem] rounded-lg hover:bg-white hover:bg-opacity-10 transition-colors flex items-center"
       >
         <img src={arrow1} alt="Arrow" className="w-5 h-5 mr-4" />
         <span className="mr-3">Change</span> {/* Yahan margin-left diya */}
       </button>
       
                       </div>
                     </div>
       
                     <div className="block lg:hidden w-full h-px bg-white opacity-20 "></div>
       
                     <div className="flex flex-col sm:flex-row items-center gap-6 mr-[30rem] ">
                       <div className="flex flex-col item-start justify-between mt-[-4rem] ">
                         {/* Active Product */}
                         <div className="flex flex-col items-center justify-between ">
                           <img
                             src={line1}
                             alt="line decoration"
                             className="w-0.5 h-10 mb-15"
                           />
                           <span className="font-medium text-[#333333] -rotate-90 whitespace-nowrap transform mt-14">
                             Active Pal
                           </span>
       
                           <img
                             src={line2}
                             alt="line decoration"
                             className="mt-14"
                           />
                         </div>
                       </div>
       
                       <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full overflow-hidden bg-gray-200 flex-shrink-0">
                         <img
                           src={selectedPal ? pals[selectedPal] : Image2}
                           alt="Pal Avatar"
                           className="w-full h-full object-cover"
                         />
                       </div>
       
                       <div className="flex flex-col items-center w-full">
       
                       <span className="font-poppins font-semibold text-[20px] leading-[30px] mr-24 whitespace-nowrap">Pal Name</span>
                       <span className="font-poppins font-medium text-[12px] leading-[18px] mr-24 whitespace-nowrap">Neha sharma</span>
       
       
                       <img
         src={Voice}
         alt="Voice Icon"
         className=" mt-7 w-[12rem] max-w-none h-12 mr-8"
       />
       
       
       
       </div>
                       <div className="flex flex-col items-center sm:items-start">
                         <div className="max-h-32 w-full overflow-y-auto mb-4">
                           <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                             {voices &&
                               Object.keys(voices).map((key, index) => (
                                 <div
                                   key={index}
                                   className={`p-2 border rounded cursor-pointer ${
                                     playingVoice === key
                                       ? "border-blue-500"
                                       : "border-white border-opacity-50"
                                   }`}
                                   onClick={() => togglePlayPause(key)}
                                 >
                                   <div className="flex justify-center items-center text-white">
                                     {playingVoice === key ? (
                                       <FaPause className="mr-2" />
                                     ) : (
                                       <FaPlay className="mr-2" />
                                     )}
                                     <span className="text-sm">
                                       {playingVoice === key ? "Pause" : "Play"}
                                     </span>
                                   </div>
                                 </div>
                               ))}
                           </div>
                         </div>
                         <button
                           onClick={openPalPopup}
                           className="px-6 py-2 border-2 text-customPurple/80 border-customPurple/80  mt-[7rem] ml-[15rem] rounded-lg hover:bg-white hover:bg-opacity-10 transition-colors flex items-center"
                         >
                           <img src={arrow1} alt="Arrow" className="w-5 h-5 mr-2" />
                           <span className="mr-3">Change</span>
                         </button>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
  
        {/* Popups */}
        {isWorkspacePopupOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
            <ToastContainer />
            <Workspace onClose={closeWorkspacePopup} workspaces={workspaces} />
          </div>
        )}
  
        {isPalPopupOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
            <Pal
              onClose={closePalPopup}
              selectedPal={selectedPal}
              onSelectPal={handlePalSelection}
              Data={Data}
              setData={setData}
              setSelectedPals={setSelectedPal}
              activePal={currentActivePal}
            />
          </div>
        )}
      </div>
    </div>
  </div>
  );
};

export default DashboardContent;
