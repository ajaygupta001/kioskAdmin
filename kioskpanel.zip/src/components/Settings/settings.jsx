import React, { useState, useEffect } from "react";
import Sidebar from "../Sidebar/Sidebar";
import Saloon from "@assets/Saloon.png";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Image2 from "@assets/image.png.png";
import Avtar from "@assets/avtar.png";
import Avtar1 from "@assets/avtar1.png";
import Avtar3 from "@assets/avtar3.png";
import Avtar5 from "@assets/avtar5.png";
import Avtar6 from "@assets/avtar6.png";
import Avtar7 from "@assets/avtar7.png";
import Avtar8 from "@assets/avtar8.png";
import Avtar9 from "@assets/avtar9.png";
import Avtar10 from "@assets/avtar10.png";
import edit1 from "@assets/edit1.png";
import twoarrow from "@assets/twoarrow.png";
import button from "@assets/button.png";
import Pal from "../Maincontent/Pal";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getAuthToken, isAuthenticated } from "/src/utils/auth"; // Adjust the path as needed

const DashboardContent = () => {
  const navigate = useNavigate();
  const [workspaces, setWorkspaces] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedPal, setSelectedPal] = useState(null);
  const [isPopupOpen, setPopupOpen] = useState(false);
  const [isloading, issetLoading] = useState(false);
  const [Data, setData] = useState("");

  const pals = {
    animeGirlBlue: Avtar,
    boyanimeBoyBlue: Avtar1,
    animeGirlDefault: Avtar3,
    IndianWoman0: Avtar5,
    boyIndianMan0: Avtar6,
    IndianWoman2: Avtar7,
    IndianWoman1: Avtar8,
    boyIndianMan2: Avtar9,
    boyIndianMan1: Avtar10,
  };

  const workspace_id = "your_workspace_id_here";

  useEffect(() => {
    const fetchWorkspace = async () => {
      try {
        const token = getAuthToken();
        if (!token) {
          throw new Error("No authentication token found. Please log in.");
        }
        const backendUrl = import.meta.env.VITE_BACKEND_URL;

        const response = await axios.get(
          `${backendUrl}/api/v1/workspace/active`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (response.status === 200) {
          issetLoading(true);
          setData(response.data.workspace);
          setSelectedPal(response.data.activeAvatar);
        }

        setWorkspaces(response.data);
        setLoading(false);
      } catch (err) {
        if (err.response?.status === 401) {
          navigate("/login");
        } else {
          console.error("Error fetching workspace data:", err);
          setError(err.response?.data?.message || err.message);
          setLoading(false);
        }
      }
    };

    fetchWorkspace();
  }, [workspace_id, navigate, isPopupOpen]);

  useEffect(() => {
    const savedPal = localStorage.getItem("selectedPal");
    if (savedPal) {
      setSelectedPal(savedPal);
    }
  }, []);

  const handlePalSelection = (palKey) => {
    setSelectedPal(palKey);
    localStorage.setItem("selectedPal", palKey);
  };

  const handleCreateClick = () => {
    navigate("/editpal");
  };

  const openPopup = () => setPopupOpen(true);
  const closePopup = () => {
    setPopupOpen(false);
  };

  if (loading) {
    return <div className="flex-1 bg-purple-50 p-8">Loading...</div>;
  }

  if (error) {
    return (
      <div className="flex-1 bg-purple-50 p-8">
        <div className="bg-red-100 text-red-700 p-4 rounded-md">{error}</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-auto">
      <Sidebar />
      <div className="flex-1 bg-purple-50 p-8 overflow-y-auto">
    
        

        <div className="flex justify-between items-center mt-8 space-x-2">
          <div className="relative">
            <div
              className="flex items-center p-6 rounded-[10px] shadow-lg"
              style={{
                width: "740px",
                height: "242px",
                background: "linear-gradient(90deg, #5941B6 0%, #A8D8FC 100%)",
              }}
            >
              <img
                src={selectedPal ? pals[selectedPal] : Image2}
                alt="Pal Avatar"
                className="w-48 h-48 object-cover rounded-lg mr-6"
              />

              <div className="text-white">
                <h2 className="text-3xl font-semibold mb-2">Reyansh</h2>
                <div className="flex items-center mb-2">
                  <span className="font-medium">English - IND</span>
                  <span className="ml-2">🇮🇳</span>
                </div>
                <p className="mb-4">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s.
                </p>
                <div className="flex">
                  <div className="ml-auto space-x-4">
                    <button
                      onClick={handleCreateClick}
                      className="relative text-white g-gradient-to-r from-purple-500 to-blue-500 border border-[#F4F3FF] px-6 py-2 rounded-lg"
                    >
                      <img
                        src={button}
                        alt="Button Icon"
                        className="absolute left-2 top-1/2 transform -translate-y-1/2 w-8 h-8 object-cover"
                      />
                      <span className="text-white text-sm font-medium ml-6 font-poppins leading-sm">
                        New
                      </span>
                    </button>

                    <button
                      className="relative text-white g-gradient-to-r from-purple-500 to-blue-500 border border-[#F4F3FF] px-6 py-2 rounded-lg"
                      onClick={openPopup}
                    >
                      <img
                        src={twoarrow}
                        alt="Button Icon"
                        className="absolute left-1 top-1/2 transform -translate-y-1/2 w-8 h-8 object-cover"
                      />
                      <span className="text-white text-sm font-medium ml-4 font-poppins leading-sm">
                        Change
                      </span>
                    </button>

                    {isPopupOpen && (
                      <div className="fixed inset-0 flex items-center justify-center mt-80 right-1/3">
                        <Pal
                          onClose={closePopup}
                          setSelectedPal={handlePalSelection}
                          selectedPal={selectedPal}
                        />
                      </div>
                    )}

                    <button
                      onClick={handleCreateClick}
                      className="relative text-white g-gradient-to-r from-purple-500 to-blue-500 border border-[#F4F3FF] px-6 py-2 rounded-lg"
                    >
                      <img
                        src={edit1}
                        alt="Button Icon"
                        className="absolute left-1 top-1/2 transform -translate-y-1/2 w-8 h-8 object-cover"
                      />
                      <span className="text-white text-sm font-medium ml-4 font-poppins leading-sm">
                        Edit
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            {isloading ? (
              <>
                <div className="w-full max-w-[740px] h-[242px] rounded-[10px] bg-gradient-to-r from-[#6B9176] to-[#A9B774] flex items-center p-4 md:p-6">
                  <img
                    src={Data.product_image}
                    alt="Product"
                    className="w-36 h-36 md:w-48 md:h-48 rounded-lg"
                  />
                  <div className="ml-4 md:ml-8">
                    <h2 className="text-white text-xl md:text-2xl font-semibold">
                      {Data.product_name}
                    </h2>
                    <p className="text-white text-xs md:text-sm mt-2">
                      {Data.product_info}
                    </p>
                    <div className="flex justify-end space-x-4 mt-4">
                      <button
                        onClick={handleCreateClick}
                        className="relative text-white g-gradient-to-r from-purple-500 to-blue-500 border border-[#F4F3FF] px-6 py-2 rounded-lg"
                      >
                        <img
                          src={button}
                          alt="Button Icon"
                          className="absolute left-2 top-1/2 transform -translate-y-1/2 w-8 h-8 object-cover"
                        />
                        <span className="text-white text-sm font-medium ml-6 font-poppins leading-sm">
                          New
                        </span>
                      </button>

                      <button
                        onClick={openPopup}
                        className="relative text-white g-gradient-to-r from-purple-500 to-blue-500 border border-[#F4F3FF] px-6 py-2 rounded-lg"
                      >
                        <img
                          src={twoarrow}
                          alt="Button Icon"
                          className="absolute left-1 top-1/2 transform -translate-y-1/2 w-8 h-8 object-cover"
                        />
                        <span className="text-white text-sm font-medium ml-4 font-poppins leading-sm">
                          Change
                        </span>
                      </button>

                      <button
                        onClick={handleCreateClick}
                        className="relative text-white g-gradient-to-r from-purple-500 to-blue-500 border border-[#F4F3FF] px-6 py-2 rounded-lg"
                      >
                        <img
                          src={edit1}
                          alt="Button Icon"
                          className="absolute left-1 top-1/2 transform -translate-y-1/2 w-8 h-8 object-cover"
                        />
                        <span className="text-white text-sm font-medium ml-4 font-poppins leading-sm">
                          Edit
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="w-full max-w-[740px] h-[242px] rounded-[10px] bg-gradient-to-r from-[#6B9176] to-[#A9B774] flex items-center p-4 md:p-6">
                <img
                  src={Saloon}
                  alt="Salon"
                  className="w-32 h-auto md:w-48 rounded-lg"
                />
                <div className="ml-4 md:ml-8">
                  <h2 className="text-white text-xl md:text-2xl font-semibold">
                    Salon App
                  </h2>
                  <p className="text-white text-xs md:text-sm mt-2">
                    Discover the best in beauty and wellness with our
                    easy-to-use salon app. Whether you need a quick trim, a
                    luxurious spa day, or the latest beauty treatment, we've got
                    you covered.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8">
          <ul className="space-y-4 mt-4">
            {Array.isArray(workspaces) &&
              workspaces.map((workspace, index) => (
                <li
                  key={index}
                  className="bg-white p-4 rounded-lg shadow-md flex justify-between items-center"
                >
                  <div>
                    <h4 className="text-lg font-medium">{workspace.name}</h4>
                    <p className="text-sm text-gray-600">
                      {workspace.description}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate(`/workspace/${workspace.id}`)}
                    className="text-purple-500 hover:underline"
                  >
                    View Workspace
                  </button>
                </li>
              ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DashboardContent;
